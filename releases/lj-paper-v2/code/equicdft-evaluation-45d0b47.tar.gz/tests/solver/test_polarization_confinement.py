"""Hard exclusion and full-Coulomb ideal-dipole equilibrium checks."""

import unittest

from tests.ideal_helpers import with_ideal
from equicdft.solver import Constraints, ConvergenceOptions, Initialization
from equicdft import FixedDipoleIdeal
import torch

from equicdft import GridCACEModel, GridSolver, LDAReadout, LongRangeReadout, MetalWall, ReciprocalFeatures
from tests.metal_helpers import wall_context as ctx
from tests.functional.test_metalwall_polarization import _case, _liquid, _oracle
from tests.solver import test_polarization_ideal as ideal_reference


class TestPolarizationConfinement(unittest.TestCase):
    def setUp(self):
        self.old_dtype = torch.get_default_dtype()
        torch.set_default_dtype(torch.float64)
        torch.manual_seed(53)

    def tearDown(self):
        torch.set_default_dtype(self.old_dtype)

    def test_confined_ideal_matches_angular_integral_both_starts(self):
        data = ideal_reference.TestGridSolverPolarization.case()
        mask = torch.arange(24) % 3 == 0
        data["excluded_mask"] = mask
        active_data = dict(data, V_ext=data["V_ext"][~mask], E_ext=data["E_ext"][~mask])
        numbers, moments = torch.tensor([3., 4.]), torch.tensor([.7, 1.9])
        expected_rho, expected_p = ideal_reference.exact_solution(active_data, numbers, moments)
        solver = GridSolver(with_ideal(None, FixedDipoleIdeal(moments)))
        for perturbed in (False, True):
            initial = {}
            if perturbed:
                rho = torch.zeros_like(data["V_ext"])
                rho[~mask] = torch.exp(.3 * torch.randn(16, 2))
                rho *= numbers / (data["grid_spacing"].prod() * rho.sum(0))
                p = .02 * (rho * moments)[..., None] * torch.randn(24, 2, 3)
                initial = dict(initial=Initialization(rho=rho, polarization=p))
            result = solver.solve(
                data,
                **initial,
                convergence=ConvergenceOptions(tolerance_residual=1e-9),
                constraints=Constraints(particle_numbers=numbers),
            )
            self.assertTrue(result["converged"])
            self.assertLess(result["maximum_residual"].item(), 1e-9)
            torch.testing.assert_close(result["rho"][~mask], expected_rho, atol=1e-9, rtol=0)
            torch.testing.assert_close(result["dipole_density"][~mask], expected_p, atol=1e-9, rtol=0)
            for key in ("rho", "dipole_density", "density_residual", "polarization_residual"):
                self.assertEqual(torch.count_nonzero(result[key][mask]).item(), 0)
            torch.testing.assert_close(result["particle_numbers"], numbers, atol=1e-13, rtol=0)

        # Excluded finite fields cannot change the accessible solution or gauge.
        changed = {**data, "V_ext": data["V_ext"].clone(), "E_ext": data["E_ext"].clone()}
        changed["V_ext"][mask] = 1000.
        changed["E_ext"][mask] = -3000.
        changed["V_ext"][~mask] += torch.tensor([2., -3.])
        shifted = solver.solve(
            changed,
            convergence=ConvergenceOptions(tolerance_residual=1e-9),
            constraints=Constraints(particle_numbers=numbers),
        )
        torch.testing.assert_close(shifted["rho"], result["rho"], atol=1e-9, rtol=0)
        torch.testing.assert_close(shifted["dipole_density"], result["dipole_density"], atol=1e-9, rtol=0)
        torch.testing.assert_close(shifted["beta_mu"] - result["beta_mu"], data["beta"] * torch.tensor([2., -3.]), atol=1e-9, rtol=0)

    def test_invalid_masks_and_excluded_initial_fields(self):
        data = ideal_reference.TestGridSolverPolarization.case()
        solver = GridSolver(with_ideal(None, FixedDipoleIdeal([.7, 1.9])))
        for mask, error in (
            (torch.ones(24, dtype=torch.bool), ValueError),
            (torch.zeros(24), TypeError),
            (torch.zeros(24, 2, dtype=torch.bool), ValueError),
        ):
            with self.assertRaises(error):
                solver.solve(
                    dict(data, excluded_mask=mask),
                    constraints=Constraints(particle_numbers=[3., 4.]),
                )
        data["excluded_mask"] = torch.arange(24) == 0
        result = solver.solve(
            data,
            constraints=Constraints(particle_numbers=[3., 4.]),
        )
        for name in ("rho", "dipole_density"):
            bad = result[name].clone()
            bad[0] = .01
            with self.assertRaisesRegex(ValueError, "zero in excluded"):
                solver.evaluate({**data, "rho": result["rho"], "dipole_density": result["dipole_density"], name: bad})

    def test_full_coulomb_matches_independent_metal_oracle(self):
        for shape in ((3, 5, 3), (4, 3, 2)):
            data, sites, charges = _case(shape, neutral_species=True)
            liquid = _liquid(charges, alpha=0.)
            energy, outputs = MetalWall(liquid, sites, metal_sigma=.35).energy_and_outputs(ctx(data))
            expected = _oracle(data, sites, charges, alpha=0.)
            torch.testing.assert_close(energy, expected["total_energy"], atol=1e-12, rtol=1e-12)
            torch.testing.assert_close(outputs["metal_site_q"], expected["metal_site_q"], atol=1e-12, rtol=1e-12)
            self.assertGreaterEqual(energy.item(), -1e-12)
        for kernel in ("gaussian", "screened_inverse_laplacian"):
            with self.assertRaises(ValueError):
                ReciprocalFeatures((0.,), kernel=kernel)
        with self.assertRaises(ValueError):
            ReciprocalFeatures((-.1,), kernel="coulomb")

    def test_manufactured_confined_metal_equilibrium(self):
        self._check_manufactured_equilibrium(gaussian=False)

    def test_gaussian_p_and_metal_equilibrium(self):
        self._check_manufactured_equilibrium(gaussian=True)

    def _check_manufactured_equilibrium(self, gaussian):
        shape = (3, 3, 8)
        data, sites, charges = _case(shape, neutral_species=True, spacing=(.8, .8, .8))
        mask = (torch.arange(72) % 8 == 0) | (torch.arange(72) % 8 == 7)
        data["excluded_mask"] = mask
        data["rho"][mask] = 0
        data["dipole_density"] *= .1
        data["dipole_density"][mask] = 0
        # Two off-grid planes, one neutral conducting group, finite field.
        sites["metal_positions"] = torch.tensor([[.2, .2, .1], [1.3, 1.4, .1], [.2, .2, 5.9], [1.3, 1.4, 5.9]])
        sites["metal_site_groups"] = torch.zeros(4, dtype=torch.long)
        sites["metal_group_ids"] = torch.tensor([0])
        sites["metal_total_charge"] = torch.zeros(1)
        wall = MetalWall(_liquid(charges, alpha=0., amplitude=.3), sites, .35, external_field=(0., 0., -.03))
        readouts = [wall]
        if gaussian:
            readouts.append(LDAReadout(zero_init=True))
            response = LongRangeReadout(
                features=ReciprocalFeatures(
                    (.1, .8), variable="dipole_density", include_divergence=True,
                ),
                hidden_sizes=(),
            )
            with torch.no_grad():
                response.mlp[-1].weight.zero_()
                response.mlp[-1].bias.copy_(torch.tensor([.2, .1, .03, .02]))
            readouts.append(response)
        model = GridCACEModel(None, None, readouts, grid_spacing=.8, mean_density=.4, boltzmann_constant=1.0).eval()
        solver = GridSolver(with_ideal(model, FixedDipoleIdeal(.7)))
        data["V_ext"] = torch.zeros_like(data["rho"])
        data["E_ext"] = torch.zeros_like(data["dipole_density"])
        target = solver.evaluate(data)
        if gaussian:
            # Both derivatives include Gaussian response and relaxed electrodes.
            for key, gradient_key in (("rho", "beta_mu_local"),
                                      ("dipole_density", "polarization_residual")):
                delta = torch.zeros_like(data[key])
                delta[9] = .001
                step = 1.e-4
                plus = solver.evaluate(dict(data, **{key: data[key] + step * delta}))
                minus = solver.evaluate(dict(data, **{key: data[key] - step * delta}))
                numeric = (plus["beta_A"] - minus["beta_A"]) / (2 * step)
                analytic = .8**3 * (target[gradient_key] * delta).sum()
                torch.testing.assert_close(numeric, analytic, rtol=1.e-6, atol=1.e-9)
        data["V_ext"] = -target["density_residual"] / data["beta"]
        data["E_ext"] = target["polarization_residual"] / data["beta"]
        result = solver.solve(
            data,
            convergence=ConvergenceOptions(tolerance_residual=1e-8),
            constraints=Constraints(particle_numbers=target["particle_numbers"]),
            initial=Initialization(rho=torch.where(mask[:, None], 0., target["particle_numbers"] / ((~mask).sum() * .8**3)), polarization=torch.zeros_like(data["dipole_density"])),
        )
        self.assertTrue(result["converged"], result["status"])
        torch.testing.assert_close(result["rho"], data["rho"], atol=1e-8, rtol=0)
        torch.testing.assert_close(result["dipole_density"], data["dipole_density"], atol=1e-8, rtol=0)
        endpoint = model(dict(data, rho=result["rho"], dipole_density=result["dipole_density"]), compute_c1=False)
        self.assertLess(endpoint["charge_residual"].item(), 1e-10)
        self.assertLess(endpoint["potential_residual"].item(), 1e-10)

    def test_homogeneous_axes_cannot_be_silently_ignored_for_dipoles(self):
        solver = GridSolver(with_ideal(None, FixedDipoleIdeal([.7, 1.9])))
        with self.assertRaisesRegex(ValueError, "not supported with fixed dipoles"):
            solver.solve(
                ideal_reference.TestGridSolverPolarization.case(),
                constraints=Constraints(particle_numbers=[3., 4.], homogeneous_axes=["x", "y"]),
            )


if __name__ == "__main__":
    unittest.main()
