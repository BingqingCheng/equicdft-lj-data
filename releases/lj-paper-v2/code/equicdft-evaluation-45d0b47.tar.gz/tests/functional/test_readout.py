import unittest

import numpy as np
import torch

from equicdft import (
    BulkReadout,
    CartesianAFeatures,
    CartesianBFeatures,
    GridCACEModel,
    LocalReadout,
    LongRangeReadout,
    ReciprocalFeatures,
)
from equicdft.derivatives import compute_grid_derivative
from equicdft.functional.base import ReadoutContext
from equicdft.geometry.stencil import get_neighbor_indices


class TestBulkReadout(unittest.TestCase):
    def test_energy_reads_the_shared_state_vector(self):
        readout = BulkReadout(n_types=2, hidden_sizes=(), zero_init=False)
        with torch.no_grad():
            readout.mlp[-1].weight.copy_(
                torch.tensor([[1.0, 2.0, -1.0], [0.5, 0.0, 3.0]])
            )
            readout.mlp[-1].bias.zero_()
        rho = torch.tensor([[[0.2, 0.4], [0.6, 0.8]], [[1.0, 1.0], [0.0, 2.0]]])
        context = ReadoutContext(
            rho=rho,
            normalized_temperature=torch.tensor([1.5, 0.5]),
            voxel_volume=0.25,
            mean_density=2.0,
        )

        energy = readout.energy(context)

        state = torch.cat(
            (context.normalized_temperature[:, None], rho.mean(-2) / 2.0), -1,
        )
        per_particle = state @ readout.mlp[-1].weight.T
        expected = 0.25 * (rho.sum(-2) * per_particle).sum(-1)
        torch.testing.assert_close(energy, expected)
        # The shared state is composed once and cached on the context.
        self.assertIs(context.state_features(), context.state_features())
        with self.assertRaisesRegex(KeyError, "mean_density"):
            readout.energy(
                ReadoutContext(
                    rho=rho,
                    normalized_temperature=torch.tensor([1.5, 0.5]),
                    voxel_volume=0.25,
                )
            )

    def test_zero_initialization_gives_zero_per_particle_energy(self):
        readout = BulkReadout(n_types=2, hidden_sizes=(4,))
        state = torch.randn(3, 3)

        output = readout(state)

        self.assertEqual(output.shape, (3, 2))
        self.assertTrue(torch.equal(output, torch.zeros_like(output)))

    def test_linear_state_mapping(self):
        readout = BulkReadout(
            n_types=1,
            hidden_sizes=(),
            zero_init=False,
        )
        with torch.no_grad():
            readout.mlp[-1].weight.copy_(torch.tensor([[2.0, -1.0]]))
            readout.mlp[-1].bias.fill_(0.5)

        output = readout(torch.tensor([[1.5, 0.25], [0.5, 2.0]]))

        self.assertTrue(
            torch.equal(output, torch.tensor([[3.25], [-0.5]]))
        )

    def test_rejects_incompatible_state_width(self):
        readout = BulkReadout(n_types=2)

        with self.assertRaisesRegex(ValueError, "state_features"):
            readout(torch.ones(4, 2))


class TestFixedLongRangeReadout(unittest.TestCase):
    def test_non_coulomb_fixed_amplitudes_need_no_state_features(self):
        for kernel in ("gaussian", "screened_inverse_laplacian"):
            with self.subTest(kernel=kernel):
                rho = torch.linspace(
                    .1, .8, 108, dtype=torch.float64,
                ).reshape(2, 27, 2).requires_grad_()
                data = {
                    "rho": rho,
                    "grid_size": torch.tensor([3, 3, 3]),
                    "grid_spacing": torch.full((3,), .5, dtype=rho.dtype),
                    "temperature": torch.tensor([1., 2.], dtype=rho.dtype),
                }
                features = ReciprocalFeatures(
                    (.25,), n_types=2, kernel=kernel, screening=.4,
                ).double()
                readout = LongRangeReadout(
                    1, n_types=2, charges=(1., -2.),
                    coulomb_amplitude=1.5, features=features,
                ).double()
                expected = 1.5 * features(
                    rho, data["grid_size"], data["grid_spacing"],
                    charges=readout.charges,
                ).sum(dim=(-2, -1))
                # A fixed amplitude needs no state vector, so the context may
                # omit the density scale entirely.
                context = ReadoutContext.from_data(data, grid_spacing=.5)
                self.assertIsNone(context.mean_density)
                torch.testing.assert_close(readout.energy(context), expected)
                expected_c1 = -torch.autograd.grad(expected.sum(), rho)[0] / .5**3
                model = GridCACEModel(
                    None, None, [readout], grid_spacing=.5,
                ).double().eval()
                output = model(data)
                torch.testing.assert_close(output["beta_F_exc"], expected)
                torch.testing.assert_close(output["c1"], expected_c1)


class TestLocalReadout(unittest.TestCase):
    def _full_pipeline(self, rho):
        shape = (4, 4, 4)
        grid_positions = np.indices(shape, dtype=int).reshape(3, -1).T
        neighbor_indices, _ = get_neighbor_indices(
            grid_positions,
            cutoff_grid=1,
        )
        data = {
            "rho": rho,
            "local_density_index": torch.tensor(
                neighbor_indices,
                dtype=torch.long,
            ),
            "grid_spacing": torch.tensor(
                [0.5, 0.5, 0.5],
                dtype=rho.dtype,
            ),
        }

        A = CartesianAFeatures(
            mean_density=0.5,
            cutoff_grid=1,
            max_power=2,
            radial_basis="gaussian",
            radial_exponents=(0.5,),
            separate_center=False,
        )(data)
        B_module = CartesianBFeatures(max_power=2, max_product_order=3)
        B = B_module(A)
        readout = LocalReadout(
            n_types=1,
            hidden_sizes=(16, 8),
        )
        local_features = B.flatten(start_dim=-3)
        readout.bind_input_size(local_features.shape[-1])
        return data, A, B, readout, readout(local_features)

    def test_batched_shapes(self):
        local_features = torch.randn(2, 5, 23)
        readout = LocalReadout(n_types=1, n_features=23)
        output = readout(local_features)

        self.assertEqual(output.shape, (2, 5, 1))
        self.assertEqual(readout.mlp[0].in_features, 23)

    def test_unbound_readout_is_bound_once(self):
        readout = LocalReadout(n_types=2, hidden_sizes=(4,))
        self.assertFalse(readout.is_bound)
        self.assertIsNone(readout.to_config()["n_features"])
        self.assertEqual(len(list(readout.parameters())), 0)
        with self.assertRaisesRegex(RuntimeError, "no input width"):
            readout(torch.zeros(3, 7))

        readout.bind_input_size(7)

        self.assertTrue(readout.is_bound)
        self.assertEqual(readout.to_config()["n_features"], 7)
        self.assertEqual(readout(torch.zeros(3, 7)).shape, (3, 2))
        parameters = list(readout.parameters())
        readout.bind_input_size(7)
        self.assertEqual([id(p) for p in readout.parameters()], [id(p) for p in parameters])
        with self.assertRaisesRegex(ValueError, "bound to 7 input features, not 9"):
            readout.bind_input_size(9)
        rebuilt = LocalReadout.from_config(readout.to_config())
        rebuilt.load_state_dict(readout.state_dict(), strict=True)

    def test_readout_uses_local_features_directly(self):
        readout = LocalReadout(
            n_types=1,
            hidden_sizes=(),
            n_features=2,
        )
        local_features = torch.tensor([[2.0, 4.0]])
        with torch.no_grad():
            readout.mlp[0].weight.copy_(torch.tensor([[1.0, 1.0]]))
            readout.mlp[0].bias.zero_()

        output = readout(local_features)
        self.assertEqual(output.item(), 6.0)

    def test_feature_scale_divides_inputs_binds_width_and_round_trips(self):
        readout = LocalReadout(n_types=1, hidden_sizes=(), feature_scale=(2.0, 4.0))
        self.assertTrue(readout.is_bound)
        self.assertEqual(readout.n_features, 2)
        with torch.no_grad():
            readout.mlp[0].weight.copy_(torch.tensor([[1.0, 1.0]]))
            readout.mlp[0].bias.zero_()
        self.assertEqual(readout(torch.tensor([[2.0, 4.0]])).item(), 2.0)
        # The scale belongs to the weights: it is in the state dict and in
        # the config, a scaled state refuses to load into an unscaled
        # readout, and an unscaled readout has no state entry at all.
        config = readout.to_config()
        self.assertEqual(config["feature_scale"], [2.0, 4.0])
        self.assertEqual(readout.state_dict()["feature_scale"].tolist(), [2.0, 4.0])
        rebuilt = LocalReadout.from_config(config)
        rebuilt.load_state_dict(readout.state_dict(), strict=True)
        self.assertEqual(rebuilt(torch.tensor([[2.0, 4.0]])).item(), 2.0)
        legacy = LocalReadout.from_config({k: v for k, v in config.items() if k != "feature_scale"})
        self.assertIsNone(legacy.feature_scale)
        self.assertNotIn("feature_scale", legacy.state_dict())
        with self.assertRaisesRegex(RuntimeError, "feature_scale"):
            legacy.load_state_dict(readout.state_dict(), strict=True)
        # A scaled readout loading a state with a different scale takes the
        # state's scale, so weights and scale stay a pair.
        other = LocalReadout(n_types=1, hidden_sizes=(), feature_scale=(1.0, 1.0))
        other.load_state_dict(readout.state_dict(), strict=True)
        self.assertEqual(other(torch.tensor([[2.0, 4.0]])).item(), 2.0)
        # Width mismatches and invalid values are rejected at construction and
        # at binding.
        with self.assertRaisesRegex(ValueError, "one value per input feature"):
            LocalReadout(n_features=3, feature_scale=(1.0, 2.0))
        with self.assertRaisesRegex(ValueError, "finite positive"):
            LocalReadout(feature_scale=(1.0, 0.0))
        with self.assertRaisesRegex(ValueError, "finite positive"):
            LocalReadout(feature_scale=(1.0, float("nan")))
        unbound = LocalReadout(hidden_sizes=(3,))
        self.assertIsNone(unbound.feature_scale)
        with self.assertRaisesRegex(RuntimeError, "bind it before"):
            unbound.set_feature_scale((1.0, 2.0))

    def test_set_feature_scale_keeps_or_changes_the_function(self):
        torch.manual_seed(5)
        readout = LocalReadout(n_types=2, hidden_sizes=(6,), n_features=4).to(torch.float64)
        inputs = torch.randn(3, 7, 4, dtype=torch.float64)
        before = readout(inputs).detach().clone()
        readout.set_feature_scale((0.5, 2.0, 10.0, 1.0e-3), keep_function=True)
        # The scale takes the weights' dtype (float64 here under a float32
        # default), so the reparametrization is exact to round-off and the
        # config reports the values the network uses.
        self.assertEqual(readout.feature_scale.dtype, torch.float64)
        torch.testing.assert_close(readout(inputs), before, rtol=1e-12, atol=1e-12)
        self.assertEqual(readout.to_config()["feature_scale"], [0.5, 2.0, 10.0, 1.0e-3])
        readout.set_feature_scale((1.0, 1.0, 5.0, 1.0), keep_function=True)
        torch.testing.assert_close(readout(inputs), before)
        readout.set_feature_scale(None, keep_function=True)
        self.assertIsNone(readout.feature_scale)
        self.assertIsNone(readout.to_config()["feature_scale"])
        torch.testing.assert_close(readout(inputs), before)
        readout.set_feature_scale((0.5, 2.0, 10.0, 1.0e-3))
        self.assertFalse(torch.allclose(readout(inputs), before))
        with self.assertRaisesRegex(ValueError, "one value per input feature"):
            readout.set_feature_scale((1.0, 2.0))

    def test_feature_offset_centres_inputs_and_is_absorbed_by_the_bias(self):
        readout = LocalReadout(n_types=1, hidden_sizes=(), feature_scale=(2.0, 4.0), feature_offset=(1.0, -4.0))
        with torch.no_grad():
            readout.mlp[0].weight.copy_(torch.tensor([[1.0, 1.0]]))
            readout.mlp[0].bias.zero_()
        # (2 - 1)/2 + (4 + 4)/4 = 2.5
        self.assertEqual(readout(torch.tensor([[2.0, 4.0]])).item(), 2.5)
        config = readout.to_config()
        self.assertEqual(config["feature_offset"], [1.0, -4.0])
        self.assertEqual(readout.state_dict()["feature_offset"].tolist(), [1.0, -4.0])
        rebuilt = LocalReadout.from_config(config)
        rebuilt.load_state_dict(readout.state_dict(), strict=True)
        self.assertEqual(rebuilt(torch.tensor([[2.0, 4.0]])).item(), 2.5)
        with self.assertRaisesRegex(ValueError, "requires a feature_scale"):
            LocalReadout(feature_offset=(1.0, 2.0))
        with self.assertRaisesRegex(ValueError, "one finite value per feature_scale"):
            LocalReadout(feature_scale=(1.0, 2.0), feature_offset=(1.0,))
        # keep_function through every combination of scale and offset changes.
        torch.manual_seed(9)
        fitted = LocalReadout(n_types=2, hidden_sizes=(6,), n_features=3).to(torch.float64)
        inputs = torch.randn(4, 5, 3, dtype=torch.float64)
        before = fitted(inputs).detach().clone()
        for scale, offset in (((2.0, 0.5, 3.0), (0.3, -1.0, 2.0)), ((1.0, 1.0, 1.0), (5.0, 5.0, 5.0)),
                              ((0.1, 0.2, 0.3), None), (None, None)):
            fitted.set_feature_scale(scale, offset, keep_function=True)
            torch.testing.assert_close(fitted(inputs), before, rtol=1e-11, atol=1e-11)
        self.assertIsNone(fitted.feature_offset)
        fitted.set_feature_scale((2.0, 0.5, 3.0), (0.3, -1.0, 2.0))
        self.assertFalse(torch.allclose(fitted(inputs), before))
        with self.assertRaisesRegex(ValueError, "requires a feature_scale"):
            fitted.set_feature_scale(None, (1.0, 2.0, 3.0))

    def test_full_autograd_and_finite_difference(self):
        torch.manual_seed(7)
        rho = torch.linspace(
            0.2,
            0.8,
            steps=64,
            dtype=torch.get_default_dtype(),
        ).reshape(64, 1)
        rho.requires_grad_(True)
        data, A, B, readout, beta_free_energy_per_particle = (
            self._full_pipeline(rho)
        )
        beta_free_energy_density = torch.sum(
            rho * beta_free_energy_per_particle,
            dim=-1,
        )
        beta_F_exc = torch.prod(data["grid_spacing"]) * torch.sum(
            beta_free_energy_density
        )

        self.assertEqual(A.shape, (64, 1, 10, 1))
        self.assertEqual(B.shape, (64, 1, 23, 1))
        self.assertEqual(
            beta_free_energy_per_particle.shape,
            (64, 1),
        )
        self.assertEqual(beta_free_energy_density.shape, (64,))
        self.assertEqual(beta_F_exc.shape, ())

        beta_F_exc_derivative = compute_grid_derivative(
            beta_F_exc,
            rho,
            create_graph=True,
        )
        self.assertEqual(beta_F_exc_derivative.shape, rho.shape)
        self.assertTrue(torch.all(torch.isfinite(beta_F_exc_derivative)))

        # Compare the raw grid derivative with a numerical derivative of the
        # complete rho -> A -> B -> F_exc pipeline.
        selected_index = 9
        # A 1e-2 central step is in the converged regime for the default
        # float32 test dtype; much smaller steps suffer subtractive cancellation.
        epsilon = 1.0e-2

        def evaluate(perturbed_rho):
            perturbed_data = dict(data)
            perturbed_data["rho"] = perturbed_rho
            perturbed_A = CartesianAFeatures(
                mean_density=0.5,
                cutoff_grid=1,
                max_power=2,
                radial_basis="gaussian",
                radial_exponents=(0.5,),
                separate_center=False,
            )(perturbed_data)
            perturbed_B = CartesianBFeatures(
                max_power=2,
                max_product_order=3,
            )(perturbed_A)
            local_features = perturbed_B.flatten(start_dim=-3)
            per_particle = readout(local_features)
            density = torch.sum(perturbed_rho * per_particle, dim=-1)
            return torch.prod(perturbed_data["grid_spacing"]) * torch.sum(
                density
            )

        rho_plus = rho.detach().clone()
        rho_minus = rho.detach().clone()
        rho_plus[selected_index, 0] += epsilon
        rho_minus[selected_index, 0] -= epsilon
        finite_difference = (
            evaluate(rho_plus) - evaluate(rho_minus)
        ) / (2.0 * epsilon)
        self.assertTrue(
            torch.allclose(
                finite_difference,
                beta_F_exc_derivative[selected_index, 0].detach(),
                atol=5.0e-6,
                rtol=5.0e-4,
            )
        )

        # A loss on a response requires second derivatives and must reach every
        # readout parameter through torch.autograd.grad(create_graph=True).
        beta_F_exc_derivative.square().mean().backward()
        gradients = [
            parameter.grad
            for parameter in readout.parameters()
            if parameter.requires_grad
        ]
        self.assertTrue(all(gradient is not None for gradient in gradients))
        self.assertTrue(
            all(torch.all(torch.isfinite(gradient)) for gradient in gradients)
        )
        self.assertGreater(
            sum(torch.sum(torch.abs(gradient)).item() for gradient in gradients),
            0.0,
        )


if __name__ == "__main__":
    unittest.main()
