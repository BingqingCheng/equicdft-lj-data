import unittest
from math import prod
from unittest.mock import patch

import torch
from torch import nn

import equicdft.training.loss as loss_module
from equicdft import (
    FixedDipoleIdeal,
    FourierResponse,
    FourierResponseLoss,
    FourierStabilityLoss,
    GridCACEModel,
    LDAReadout,
    Loss,
    LossTerm,
    TensorLoss,
)
from equicdft.geometry.grid import voxel_volume
from equicdft.response.curvature import polarization_fourier_curvature
from equicdft.response.stability import _feasible_wavevector_indices


class _PredictionPenalty(LossTerm):
    """Minimal specialized term used to test loss aggregation."""

    def __init__(self):
        super().__init__("prediction_penalty")

    def evaluate(self, outputs, batch, model=None):
        return {"loss": outputs["c1"].abs().mean(), "model_seen": model is not None}


class _UnnamedTerm(nn.Module):
    """A plain module is not a loss term, however loss-like it looks."""

    name = "plain"

    def forward(self, outputs, batch):
        return outputs["c1"].abs().mean()


class _QuadraticExcessModel(nn.Module):
    """Analytic local functional used to test projected curvature."""

    def __init__(self, coefficient):
        super().__init__()
        self.coefficient = nn.Parameter(torch.tensor(float(coefficient)))
        self.last_rho = None

    def forward(self, data, compute_c1=None):
        rho = data["rho"]
        volume_element = voxel_volume(data["grid_spacing"].to(rho))
        self.last_rho = rho.detach()
        return {
            "beta_F_exc": (
                0.5
                * self.coefficient.to(rho)
                * volume_element
                * torch.sum(rho.square(), dim=(-2, -1))
            )
        }


class _CoupledQuadraticExcessModel(nn.Module):
    """Analytic mixture functional with an explicit component Hessian."""

    def __init__(self, matrix):
        super().__init__()
        self.matrix = nn.Parameter(torch.as_tensor(matrix, dtype=torch.float64))

    def forward(self, data, compute_c1=None):
        rho = data["rho"]
        volume_element = voxel_volume(data["grid_spacing"].to(rho))
        return {
            "beta_F_exc": (
                0.5
                * volume_element
                * torch.einsum(
                    "...gi,ij,...gj->...",
                    rho,
                    self.matrix.to(rho),
                    rho,
                )
            )
        }


class _PolarizationQuadraticExcessModel(nn.Module):
    """Analytic local polarization functional with a Cartesian Hessian."""

    def __init__(self, matrix, moment=1.0):
        super().__init__()
        self.matrix = nn.Parameter(torch.as_tensor(matrix, dtype=torch.float64))
        self.ideal = FixedDipoleIdeal(moment)
        self.last_polarization = None

    def forward(self, data, compute_c1=None, compute_ideal=False):
        polarization = data["dipole_density"]
        volume_element = voxel_volume(data["grid_spacing"].to(polarization))
        self.last_polarization = polarization.detach()
        return {
            "beta_F_exc": (
                0.5
                * volume_element
                * torch.einsum(
                    "...gai,ij,...gaj->...",
                    polarization,
                    self.matrix.to(polarization),
                    polarization,
                )
            )
        }


class _TargetValueLoss(nn.Module):
    """Return the supplied target elementwise to isolate loss reduction."""

    def forward(self, prediction, target):
        return target


class TestTensorLoss(unittest.TestCase):
    def test_weighted_loss_and_gradient(self):
        prediction = torch.tensor([1.0, 3.0], requires_grad=True)
        term = TensorLoss(
            name="c1",
            prediction_key="predicted_c1",
            target_key="c1",
            loss_fn=nn.MSELoss(),
            weight=2.0,
        )

        value = term(
            {"predicted_c1": prediction},
            {"c1": torch.tensor([0.0, 1.0])},
        )
        value.backward()

        self.assertAlmostEqual(value.item(), 5.0)
        self.assertTrue(
            torch.allclose(prediction.grad, torch.tensor([2.0, 4.0]))
        )

    def test_default_is_mean_squared_error(self):
        term = TensorLoss("c1", "c1", "c1")
        value = term(
            {"c1": torch.tensor([1.0, 3.0])},
            {"c1": torch.tensor([0.0, 1.0])},
        )
        self.assertAlmostEqual(value.item(), 2.5)

    def test_shapes_must_match_exactly(self):
        term = TensorLoss("c1", "c1", "c1")
        with self.assertRaisesRegex(ValueError, "shape"):
            term(
                {"c1": torch.ones(2, 3, 1)},
                {"c1": torch.ones(6, 1)},
            )

    def test_missing_prediction_and_target_are_reported(self):
        term = TensorLoss("c1", "predicted_c1", "target_c1")
        with self.assertRaisesRegex(KeyError, "prediction"):
            term({}, {"target_c1": torch.tensor(0.0)})
        with self.assertRaisesRegex(KeyError, "target"):
            term({"predicted_c1": torch.tensor(0.0)}, {})

    def test_loss_function_must_return_scalar(self):
        term = TensorLoss(
            "c1",
            "c1",
            "c1",
            loss_fn=nn.MSELoss(reduction="none"),
        )
        with self.assertRaisesRegex(ValueError, "scalar"):
            term({"c1": torch.ones(2)}, {"c1": torch.zeros(2)})

    def test_weight_must_be_finite_and_nonnegative(self):
        for weight in (-1.0, float("inf"), float("nan")):
            with self.subTest(weight=weight):
                with self.assertRaisesRegex(ValueError, "weight"):
                    TensorLoss("c1", "c1", "c1", weight=weight)
        with self.assertRaisesRegex(TypeError, "weight"):
            TensorLoss("c1", "c1", "c1", weight="invalid")


class TestWeightedTensorLoss(unittest.TestCase):
    @staticmethod
    def _example():
        rho = torch.tensor([[[1.0], [2.0], [0.0], [4.0]]])
        local = torch.tensor(
            [[[1.0], [3.0], [0.0], [5.0]]],
            requires_grad=True,
        )
        outputs = {
            "beta_mu_local": local,
            "beta_mu_average": local[:, [0, 1, 3], :].mean(
                dim=-2
            ),
            "voxel_weights": (rho > 0.5).to(rho.dtype),
        }
        return outputs, {}

    @staticmethod
    def _loss():
        return TensorLoss(
            name="beta_mu_local",
            prediction_key="beta_mu_local",
            target_key="beta_mu_average",
            weights_key="voxel_weights",
        )

    def test_unknown_mu_is_masked_spatial_mean(self):
        outputs, batch = self._example()
        loss = self._loss()(outputs, batch)
        self.assertAlmostEqual(loss.item(), 8.0 / 3.0, places=6)
        loss.backward()
        local = outputs["beta_mu_local"]
        self.assertTrue(torch.all(torch.isfinite(local.grad)))
        self.assertEqual(local.grad[0, 2, 0].item(), 0.0)

    def test_known_beta_mu_is_selected_from_batch(self):
        outputs, _ = self._example()
        loss = TensorLoss(
            name="beta_mu_local",
            prediction_key="beta_mu_local",
            target_key="beta_mu",
            weights_key="voxel_weights",
        )(outputs, {"beta_mu": torch.tensor([[2.0]])})
        self.assertAlmostEqual(loss.item(), 11.0 / 3.0, places=6)

    def test_ordered_targets_mix_known_and_inferred_mu(self):
        prediction = torch.tensor(
            [[[1.0], [3.0]], [[4.0], [6.0]]],
            requires_grad=True,
        )
        outputs = {
            "beta_mu_local": prediction,
            "beta_mu_average": torch.tensor([[2.0], [5.0]]),
            "voxel_weights": torch.ones_like(prediction),
        }
        batch = {"beta_mu": torch.tensor([[float("nan")], [4.0]])}
        term = TensorLoss(
            name="beta_mu_local",
            prediction_key="beta_mu_local",
            target_key=("beta_mu", "beta_mu_average"),
            weights_key="voxel_weights",
        )
        loss = term(outputs, batch)
        loss.backward()
        self.assertAlmostEqual(loss.item(), 1.5, places=6)
        self.assertTrue(torch.all(torch.isfinite(prediction.grad)))

    def test_ordered_targets_require_a_complete_finite_fallback(self):
        prediction = torch.ones(1, 2, 1)
        term = TensorLoss(
            "mu",
            "local_mu",
            ("beta_mu", "average_mu"),
        )
        with self.assertRaisesRegex(KeyError, "target candidates"):
            term({"local_mu": prediction}, {})
        with self.assertRaisesRegex(ValueError, "unresolved nonfinite"):
            term(
                {"local_mu": prediction},
                {"beta_mu": torch.tensor([[float("nan")]])},
            )

    def test_ordered_target_configuration_is_validated(self):
        for target_key in ((), ("beta_mu", "beta_mu"), ("beta_mu", "")):
            with self.subTest(target_key=target_key):
                with self.assertRaisesRegex(ValueError, "target_key"):
                    TensorLoss("mu", "local_mu", target_key)

    def test_zero_total_element_weight_is_rejected(self):
        outputs, batch = self._example()
        outputs["voxel_weights"].zero_()
        with self.assertRaisesRegex(ValueError, "positive sum"):
            self._loss()(outputs, batch)

    def test_voxel_weights_expand_over_vector_components(self):
        for shape in ((5, 2, 3), (2, 5, 2, 3)):
            for center_axis in (None, -3):
                with self.subTest(shape=shape, center_axis=center_axis):
                    prediction = torch.arange(prod(shape), dtype=torch.float64).reshape(shape)
                    prediction.requires_grad_()
                    target = torch.sin(prediction.detach())
                    weights = torch.ones(shape[:-1], dtype=torch.float64)
                    weights[..., 0, :] = 0.
                    weights[..., 1, :] = .4
                    outputs = dict(P=prediction, voxel_weights=weights)
                    # Output selection wins over a stale batch selection.
                    batch = dict(target=target, voxel_weights=torch.zeros_like(weights))
                    term = TensorLoss('P', 'P', 'target', weights_key='voxel_weights',
                                      center_axis=center_axis, residual_scale=torch.tensor([[.5], [.8]]))
                    actual = term(outputs, batch)
                    expected = term(dict(outputs, voxel_weights=weights[..., None].expand_as(prediction)), batch)
                    torch.testing.assert_close(actual, expected)
                    actual_grad, = torch.autograd.grad(actual, prediction, retain_graph=True)
                    expected_grad, = torch.autograd.grad(expected, prediction)
                    torch.testing.assert_close(actual_grad, expected_grad)
                    self.assertTrue(torch.equal(actual_grad[..., 0, :, :], torch.zeros_like(actual_grad[..., 0, :, :])))

    def test_vector_weights_reject_missing_species_axis(self):
        term = TensorLoss('P', 'P', 'target', weights_key='voxel_weights')
        prediction = torch.ones(2, 5, 2, 3)
        with self.assertRaisesRegex(ValueError, 'weights and prediction'):
            term(dict(P=prediction, voxel_weights=torch.ones(2, 5)), dict(target=prediction))


class TestSmoothedTensorLoss(unittest.TestCase):
    """``residual_smoothing`` filters the masked residual on the grid."""

    GRID = (6, 5, 4)
    SPACING = (2.0, 1.0, 0.5)

    @classmethod
    def _batch(cls, target, n_fields=1):
        return {
            "target": target,
            "grid_size": torch.tensor([list(cls.GRID)] * n_fields),
            "grid_spacing": torch.tensor([list(cls.SPACING)] * n_fields, dtype=torch.float64),
        }

    @staticmethod
    def _term(sigma, **kwargs):
        return TensorLoss(
            "P", "P", "target", weights_key="voxel_weights",
            residual_smoothing=sigma, **kwargs,
        )

    @classmethod
    def _axis_wave(cls, axis, harmonic, n_species=2):
        """A pure cosine of the given harmonic along one grid axis."""

        index = torch.arange(cls.GRID[axis], dtype=torch.float64)
        wave = torch.cos(2.0 * torch.pi * harmonic * index / cls.GRID[axis])
        shape = [1, 1, 1]
        shape[axis] = cls.GRID[axis]
        wave = wave.reshape(shape).expand(cls.GRID).reshape(1, -1, 1, 1)
        return wave.expand(1, -1, n_species, 3).contiguous()

    def test_zero_or_absent_smoothing_is_the_unsmoothed_loss(self):
        torch.manual_seed(3)
        prediction = torch.randn(1, prod(self.GRID), 2, 3, dtype=torch.float64, requires_grad=True)
        target = torch.randn_like(prediction)
        weights = (torch.rand(1, prod(self.GRID), 2, dtype=torch.float64) > 0.3).double()
        outputs = dict(P=prediction, voxel_weights=weights)
        scale = torch.tensor([[0.5], [0.8]], dtype=torch.float64)
        reference = self._term(None, residual_scale=scale)(outputs, self._batch(target))
        for sigma in (0, 0.0):
            with self.subTest(sigma=sigma):
                term = self._term(sigma, residual_scale=scale)
                self.assertIsNone(term.residual_smoothing)
                value = term(outputs, self._batch(target))
                self.assertTrue(torch.equal(value, reference))
        # Smoothing works without any grid geometry when it is off.
        self.assertTrue(torch.equal(
            self._term(0.0, residual_scale=scale)(outputs, {"target": target}), reference,
        ))

    def test_smoothing_is_the_reciprocal_gaussian_of_the_residual(self):
        sigma = 1.5
        n_species = 2
        target = torch.zeros(1, prod(self.GRID), n_species, 3, dtype=torch.float64)
        weights = torch.ones(1, prod(self.GRID), n_species, dtype=torch.float64)
        smoothed = self._term(sigma)
        plain = self._term(None)
        # A constant residual is not attenuated at all.
        outputs = dict(P=torch.ones_like(target), voxel_weights=weights)
        torch.testing.assert_close(smoothed(outputs, self._batch(target)), plain(outputs, self._batch(target)))
        # One cosine along each axis is attenuated by exp(-sigma^2 k^2) in the
        # squared residual, with k from that axis's own spacing (Nyquist on x).
        for axis, harmonic in ((0, 3), (1, 1), (2, 1)):
            with self.subTest(axis=axis, harmonic=harmonic):
                outputs = dict(P=self._axis_wave(axis, harmonic, n_species), voxel_weights=weights)
                wavenumber = 2.0 * torch.pi * harmonic / (self.GRID[axis] * self.SPACING[axis])
                ratio = smoothed(outputs, self._batch(target)) / plain(outputs, self._batch(target))
                torch.testing.assert_close(
                    ratio, torch.exp(torch.tensor(-sigma ** 2 * wavenumber ** 2, dtype=torch.float64)),
                )

    def test_smoothing_matches_explicit_fourier_filter_and_backpropagates(self):
        torch.manual_seed(5)
        sigma = 2.0
        n = prod(self.GRID)
        prediction = torch.randn(1, n, 2, 3, dtype=torch.float64, requires_grad=True)
        target = torch.randn_like(prediction)
        weights = (torch.rand(1, n, 2, dtype=torch.float64) > 0.3).double()
        scale = torch.tensor([[0.5], [0.8]], dtype=torch.float64)
        term = self._term(sigma, residual_scale=scale, weight=0.36)
        value = term(dict(P=prediction, voxel_weights=weights), self._batch(target))

        residual = scale * (prediction - target)
        selected = weights[..., None].expand_as(residual) > 0
        residual = torch.where(selected, residual, torch.zeros_like(residual))
        axes = [
            2.0 * torch.pi * torch.fft.fftfreq(size, d=spacing, dtype=torch.float64)
            for size, spacing in zip(self.GRID, self.SPACING)
        ]
        kx, ky, kz = torch.meshgrid(*axes, indexing="ij")
        transfer = torch.exp(-0.5 * sigma ** 2 * (kx ** 2 + ky ** 2 + kz ** 2))
        grid = residual.reshape(1, *self.GRID, 2, 3)
        filtered = torch.fft.ifftn(
            torch.fft.fftn(grid, dim=(1, 2, 3)) * transfer[None, ..., None, None], dim=(1, 2, 3),
        ).real.reshape_as(residual)
        expected = 0.36 * (filtered.square() * selected).sum() / selected.sum()
        torch.testing.assert_close(value, expected)

        actual_grad, = torch.autograd.grad(value, prediction, retain_graph=True)
        expected_grad, = torch.autograd.grad(expected, prediction)
        torch.testing.assert_close(actual_grad, expected_grad)
        self.assertTrue(torch.all(actual_grad[~selected] == 0))

    def test_unselected_voxels_do_not_supply_or_score_residual(self):
        n = prod(self.GRID)
        weights = torch.ones(1, n, 1, dtype=torch.float64)
        weights[0, :5, 0] = 0.0
        target = torch.zeros(1, n, 1, 3, dtype=torch.float64)
        term = self._term(1.0)
        # Residual only on unselected voxels: nothing reaches the selected ones.
        prediction = torch.zeros_like(target)
        prediction[0, :5] = 7.0
        self.assertEqual(term(dict(P=prediction, voxel_weights=weights), self._batch(target)).item(), 0.0)
        # Changing an unselected voxel never changes the loss.
        torch.manual_seed(1)
        prediction = torch.randn_like(target)
        value = term(dict(P=prediction, voxel_weights=weights), self._batch(target))
        prediction[0, :5] += 3.0
        torch.testing.assert_close(term(dict(P=prediction, voxel_weights=weights), self._batch(target)), value)

    def test_smoothing_requires_finite_hard_weights(self):
        n = prod(self.GRID)
        prediction = torch.ones(1, n, 1, 3, dtype=torch.float64)
        target = torch.zeros_like(prediction)
        term = self._term(1.0)
        for value, message in (
            (0.4, "hard zero/one"),
            (-1.0, "hard zero/one"),
            (float("nan"), "finite"),
            (float("inf"), "finite"),
        ):
            with self.subTest(value=value):
                weights = torch.ones(1, n, 1, dtype=torch.float64)
                weights[0, 0, 0] = value
                with self.assertRaisesRegex(ValueError, message):
                    term(dict(P=prediction, voxel_weights=weights), self._batch(target))

    def test_smoothing_weight_checks_are_local_to_reentrant_evaluations(self):
        n = prod(self.GRID)
        prediction = torch.ones(1, n, 1, 3, dtype=torch.float64)
        target = torch.zeros_like(prediction)
        valid_weights = torch.ones(1, n, 1, dtype=torch.float64)
        invalid_weights = valid_weights.clone()
        invalid_weights[0, 0, 0] = 0.4
        term = self._term(1.0)
        batch = self._batch(target)

        class ReentrantMSE(nn.Module):
            def __init__(self):
                super().__init__()
                self.entered = False

            def forward(self, first, second):
                if not self.entered:
                    self.entered = True
                    term(dict(P=prediction, voxel_weights=valid_weights), batch)
                return (first - second).square()

        term.loss_fn = ReentrantMSE()
        with self.assertRaisesRegex(ValueError, "hard zero/one"):
            term(dict(P=prediction, voxel_weights=invalid_weights), batch)

    def test_smoothing_transfer_is_cached_by_geometry_and_tensor_type(self):
        n = prod(self.GRID)
        prediction = torch.ones(1, n, 1, 3, dtype=torch.float64)
        target = torch.zeros_like(prediction)
        weights = torch.ones(1, n, 1, dtype=torch.float64)
        outputs = dict(P=prediction, voxel_weights=weights)
        term = self._term(1.0)
        with patch(
            "equicdft.training.loss._gaussian_transfer",
            wraps=loss_module._gaussian_transfer,
        ) as transfer:
            term(outputs, self._batch(target))
            term(outputs, self._batch(target))
            self.assertEqual(transfer.call_count, 1)

            changed = self._batch(target)
            changed["grid_spacing"] = 2.0 * changed["grid_spacing"]
            term(outputs, changed)
            self.assertEqual(transfer.call_count, 2)
            self.assertEqual(len(term._smoothing_transfer_cache), 1)

            term.to(dtype=torch.float32)
            self.assertEqual(len(term._smoothing_transfer_cache), 0)

    def test_smoothing_supports_scalar_grid_fields(self):
        """A genuine ``[n_fields, n_grid]`` field smooths like its one-species form."""

        torch.manual_seed(11)
        n = prod(self.GRID)
        prediction = torch.randn(2, n, dtype=torch.float64)
        target = torch.randn_like(prediction)
        weights = (torch.rand(2, n, dtype=torch.float64) > 0.3).double()
        term = self._term(1.0)
        scalar = term(dict(P=prediction, voxel_weights=weights), self._batch(target, n_fields=2))
        one_species = term(
            dict(P=prediction[..., None], voxel_weights=weights[..., None]),
            self._batch(target[..., None], n_fields=2),
        )
        torch.testing.assert_close(scalar, one_species)
        self.assertGreater(scalar.item(), 0.0)
        # Unsmoothed, the same fields give the plain masked mean-squared error.
        plain = self._term(None)(dict(P=prediction, voxel_weights=weights), self._batch(target, n_fields=2))
        expected = ((prediction - target).square() * weights).sum() / weights.sum()
        torch.testing.assert_close(plain, expected)

    def test_fixed_grid_reads_the_geometry_once_and_shares_one_host_transfer(self):
        n = prod(self.GRID)
        prediction = torch.ones(1, n, 1, 3, dtype=torch.float64)
        target = torch.zeros_like(prediction)
        weights = torch.ones(1, n, 1, dtype=torch.float64)
        outputs = dict(P=prediction, voxel_weights=weights)
        fixed = self._term(1.0, fixed_grid=True)
        checked = self._term(1.0)
        with patch(
            "equicdft.training.loss._shared_grid_geometry",
            wraps=loss_module._shared_grid_geometry,
        ) as geometry:
            first = fixed(outputs, self._batch(target))
            second = fixed(outputs, self._batch(target))
            self.assertEqual(geometry.call_count, 1)
            checked(outputs, self._batch(target))
            checked(outputs, self._batch(target))
            self.assertEqual(geometry.call_count, 3)
        torch.testing.assert_close(first, second)
        torch.testing.assert_close(first, checked(outputs, self._batch(target)))
        # After the first evaluation the smoothing path makes one
        # device-to-host transfer per evaluation, the shared weight checks and
        # weight total; the geometry is no longer read. (The remaining
        # ``item`` is ``resolve_target``'s finite-target check, common to
        # every TensorLoss.)
        transfers = []
        original = {name: getattr(torch.Tensor, name) for name in ("item", "tolist", "cpu")}
        def counting(name):
            def wrapper(tensor, *args, **kwargs):
                transfers.append(name)
                return original[name](tensor, *args, **kwargs)
            return wrapper
        with patch.object(torch.Tensor, "item", counting("item")), \
                patch.object(torch.Tensor, "tolist", counting("tolist")), \
                patch.object(torch.Tensor, "cpu", counting("cpu")):
            fixed(outputs, self._batch(target))
        self.assertEqual(transfers, ["item", "tolist"])
        # The number of grid points is still checked; a different grid is rejected.
        other = torch.ones(1, 2 * n, 1, 3, dtype=torch.float64)
        batch = self._batch(torch.zeros_like(other))
        batch["grid_size"] = torch.tensor([[12, 5, 4]])
        with self.assertRaisesRegex(ValueError, "fixed_grid"):
            fixed(dict(P=other, voxel_weights=torch.ones(1, 2 * n, 1, dtype=torch.float64)), batch)
        with self.assertRaisesRegex(TypeError, "fixed_grid"):
            self._term(1.0, fixed_grid="yes")

    def test_smoothing_supports_scalar_species_fields_and_several_fields(self):
        torch.manual_seed(7)
        n = prod(self.GRID)
        prediction = torch.randn(2, n, 2, dtype=torch.float64)
        target = torch.randn_like(prediction)
        weights = torch.ones(2, n, 2, dtype=torch.float64)
        term = self._term(1.0)
        batched = term(dict(P=prediction, voxel_weights=weights), self._batch(target, n_fields=2))
        separate = [
            term(dict(P=prediction[[field]], voxel_weights=weights[[field]]), self._batch(target[[field]]))
            for field in range(2)
        ]
        torch.testing.assert_close(batched, 0.5 * (separate[0] + separate[1]))
        # A single shared grid row serves every field, as for common_grid_size.
        shared = self._batch(target)
        shared["target"] = target
        torch.testing.assert_close(term(dict(P=prediction, voxel_weights=weights), shared), batched)

    def test_smoothing_configuration_and_geometry_are_validated(self):
        with self.assertRaisesRegex(ValueError, "residual_smoothing"):
            self._term(-1.0)
        with self.assertRaisesRegex(TypeError, "residual_smoothing"):
            self._term(True)
        n = prod(self.GRID)
        prediction = torch.ones(1, n, 1, 3, dtype=torch.float64)
        weights = torch.ones(1, n, 1, dtype=torch.float64)
        target = torch.zeros_like(prediction)
        term = self._term(1.0)
        outputs = dict(P=prediction, voxel_weights=weights)
        with self.assertRaisesRegex(KeyError, "grid_size"):
            term(outputs, {"target": target, "grid_spacing": torch.ones(1, 3)})
        with self.assertRaisesRegex(KeyError, "grid_spacing"):
            term(outputs, {"target": target, "grid_size": torch.tensor([list(self.GRID)])})
        batch = self._batch(target)
        batch["grid_size"] = torch.tensor([[6, 5, 5]])
        with self.assertRaisesRegex(ValueError, "grid_size product"):
            term(outputs, batch)
        batch = self._batch(target, n_fields=2)
        batch["grid_spacing"][1, 0] = 3.0
        with self.assertRaisesRegex(ValueError, "share grid_spacing"):
            term(dict(P=prediction.expand(2, n, 1, 3), voxel_weights=weights.expand(2, n, 1)),
                 dict(batch, target=target.expand(2, n, 1, 3)))
        flat = torch.ones(n, dtype=torch.float64)
        with self.assertRaisesRegex(ValueError, r"\[n_fields, n_grid"):
            term(dict(P=flat, voxel_weights=flat), dict(self._batch(target), target=flat))


class TestFourierStabilityLoss(unittest.TestCase):
    @staticmethod
    def _batch(dtype=torch.float64, n_fields=1):
        n_grid = 8
        return {
            "rho": torch.full(
                (n_fields, n_grid, 1),
                0.5,
                dtype=dtype,
            ),
            "temperature": torch.ones(n_fields, dtype=dtype),
            "grid_spacing": torch.ones(n_fields, 3, dtype=dtype),
            "grid_size": torch.tensor(
                [[n_grid, 1, 1]] * n_fields
            ),
            "grid_positions": torch.tensor(
                [
                    [[index, 0, 0] for index in range(n_grid)]
                    for _ in range(n_fields)
                ]
            ),
        }

    @staticmethod
    def _add_polarization(batch):
        batch["dipole_density"] = batch["rho"].new_zeros(
            (*batch["rho"].shape, 3)
        )
        return batch

    def test_stable_ideal_curvature_has_zero_penalty(self):
        batch = self._batch()
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        outputs = model(batch)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
        )

        value = term(outputs, batch, model=model)

        self.assertEqual(value.item(), 0.0)

    def test_polarization_wavevector_treatment_is_explicit(self):
        batch = self._add_polarization(self._batch())
        model = _PolarizationQuadraticExcessModel(-12.0 * torch.eye(3))
        common = {
            "wavevector_indices": ((1, 0, 0), (2, 0, 0)),
            "variable": "dipole_density",
            "include_zero_wavevector": False,
        }

        for treatment, expected_shape in (
            ("independent", (1, 2, 2)),
            ("superposition", (1, 1, 1)),
        ):
            with self.subTest(wavevector_treatment=treatment):
                term = FourierStabilityLoss(
                    wavevector_treatment=treatment,
                    **common,
                )
                with patch(
                    "equicdft.response.stability.polarization_fourier_curvature",
                    wraps=polarization_fourier_curvature,
                ) as response:
                    value = term(model(batch), batch, model=model)
                kwargs = response.call_args.kwargs
                if treatment == "independent":
                    self.assertNotIn("wavevector_phases", kwargs)
                else:
                    self.assertEqual(
                        kwargs["wavevector_phases"].shape,
                        (1, 2),
                    )
                curvature, valid = polarization_fourier_curvature(**kwargs)
                self.assertEqual(curvature.shape, expected_shape)
                self.assertEqual(valid.shape, expected_shape)
                self.assertGreater(value.item(), 0.0)
                value.backward()
                self.assertTrue(torch.all(torch.isfinite(model.matrix.grad)))
                model.matrix.grad.zero_()

    def test_superposed_polarization_keeps_zero_wavevector_independent(self):
        batch = self._add_polarization(self._batch())
        model = _PolarizationQuadraticExcessModel(torch.zeros(3, 3))
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0), (2, 0, 0)),
            variable="dipole_density",
            wavevector_treatment="superposition",
            include_zero_wavevector=True,
        )

        with patch(
            "equicdft.response.stability.polarization_fourier_curvature",
            wraps=polarization_fourier_curvature,
        ) as response:
            term(model(batch), batch, model=model)

        self.assertEqual(response.call_count, 2)
        superposed, zero = (call.kwargs for call in response.call_args_list)
        self.assertEqual(superposed["wavevector_phases"].shape, (1, 2))
        self.assertNotIn("wavevector_phases", zero)
        self.assertTrue(torch.all(zero["wavevector_indices"] == 0).item())

    def test_polarization_ideal_has_zero_penalty_and_unstable_block_backpropagates(self):
        batch = self._add_polarization(self._batch())
        stable = _PolarizationQuadraticExcessModel(torch.zeros(3, 3))
        common = {
            "wavevector_indices": ((1, 0, 0),),
            "variable": "dipole_density",
            "relative_amplitude": 2.0**-10,
            "include_zero_wavevector": False,
        }

        self.assertEqual(
            FourierStabilityLoss(**common)(stable(batch), batch, model=stable).item(),
            0.0,
        )

        # At rho=1/2 and P=0 the ideal Cartesian Hessian is 3/rho=6.
        # Adding -12 I therefore gives the ideal-metric matrix -I.
        unstable = _PolarizationQuadraticExcessModel(-12.0 * torch.eye(3))
        value = FourierStabilityLoss(**common)(
            unstable(batch), batch, model=unstable
        )
        value.backward()

        rho = batch["rho"]
        polarization = batch["dipole_density"]
        phase = (
            2.0
            * torch.pi
            * batch["grid_positions"][0, :, 0].to(rho)
            / 8.0
        )
        expected = []
        for wave in (torch.cos(phase), torch.sin(phase)):
            delta = torch.zeros_like(polarization)
            delta[..., 0] = common["relative_amplitude"] * rho * wave[None, :, None]
            ideal_second = 3.0 * (delta.square() / rho[..., None]).sum()
            excess_second = -12.0 * delta.square().sum()
            expected.append((1.0 + excess_second / ideal_second).square())
        expected = torch.stack(expected).mean()
        torch.testing.assert_close(value, expected)
        self.assertTrue(torch.all(torch.isfinite(unstable.matrix.grad)))
        self.assertGreater(torch.linalg.vector_norm(unstable.matrix.grad).item(), 0.0)

    def test_polarization_result_is_independent_of_species_count(self):
        batch = self._batch()
        batch["rho"] = torch.cat((batch["rho"], 0.6 * batch["rho"]), dim=-1)
        self._add_polarization(batch)
        model = _PolarizationQuadraticExcessModel(torch.zeros(3, 3))
        model.ideal = FixedDipoleIdeal([0.7, 1.3])
        modes = torch.tensor([[[1, 0, 0]]])

        curvature, active = polarization_fourier_curvature(
            model=model,
            outputs=model(batch),
            batch=batch,
            rho=batch["rho"],
            wavevector_indices=modes,
            relative_amplitude=0.05,
            polarization_directions=torch.tensor([[0.0, 0.0, 1.0]]),
        )

        self.assertEqual(curvature.shape, (1, 1, 2))
        self.assertEqual(active.shape, (1, 1, 2))
        torch.testing.assert_close(
            curvature[active],
            torch.ones_like(curvature[active]),
            atol=2.0e-11,
            rtol=2.0e-11,
        )

    def test_polarization_draws_one_spherical_direction_per_field(self):
        batch = self._add_polarization(self._batch(n_fields=2))
        model = _PolarizationQuadraticExcessModel(torch.zeros(3, 3))
        draws = torch.tensor(
            [[2.0, 0.0, 0.0], [1.0, 2.0, 2.0]],
            dtype=batch["rho"].dtype,
        )
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            variable="dipole_density",
            relative_amplitude=0.05,
            include_zero_wavevector=False,
        )

        with patch("equicdft.response.stability.torch.randn", return_value=draws):
            term(model(batch), batch, model=model)

        first_cosine_plus = model.last_polarization[:, 0, 0, 0]
        observed = first_cosine_plus / torch.linalg.vector_norm(
            first_cosine_plus, dim=-1, keepdim=True
        )
        expected = draws / torch.linalg.vector_norm(draws, dim=-1, keepdim=True)
        torch.testing.assert_close(observed, expected)

    def test_polarization_zero_mode_keeps_cosine_and_discards_sine(self):
        batch = self._add_polarization(self._batch())
        model = _PolarizationQuadraticExcessModel(torch.zeros(3, 3))
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            variable="dipole_density",
        )

        selected = torch.zeros((1, 1, 3), dtype=torch.long)
        curvature, active = polarization_fourier_curvature(
            model=model,
            outputs=model(batch),
            batch=batch,
            rho=batch["rho"],
            wavevector_indices=selected,
            relative_amplitude=0.05,
            polarization_directions=torch.tensor([[0.0, 1.0, 0.0]]),
        )

        self.assertTrue(active[:, :, 0].all())
        self.assertFalse(active[:, :, 1].any())
        torch.testing.assert_close(curvature[0, 0, 0], curvature.new_tensor(1.0))

        with patch(
            "equicdft.response.stability.polarization_fourier_curvature",
            wraps=polarization_fourier_curvature,
        ) as response:
            term(model(batch), batch, model=model)
        supplied_modes = response.call_args.kwargs["wavevector_indices"]
        self.assertTrue(torch.equal(supplied_modes[:, 0], selected[:, 0]))

    def test_polarization_stability_does_not_impose_fixed_dipole_boundary(self):
        batch = self._add_polarization(self._batch())
        batch["dipole_density"][..., 0] = 1.05 * batch["rho"]
        model = _PolarizationQuadraticExcessModel(torch.zeros(3, 3))
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            variable="dipole_density",
            relative_amplitude=0.1,
            include_zero_wavevector=False,
        )

        direction = torch.tensor([[1.0, 0.0, 0.0]], dtype=batch["rho"].dtype)
        with patch("equicdft.response.stability.torch.randn", return_value=direction):
            value = term(model(batch), batch, model=model)

        perturbed_q = model.last_polarization / batch["rho"][:, None, :, :, None]
        self.assertGreater(
            torch.linalg.vector_norm(perturbed_q, dim=-1).max().item(),
            1.0,
        )
        self.assertTrue(torch.isfinite(value).item())

    def test_polarization_stability_integrates_with_grid_model(self):
        batch = self._add_polarization(self._batch())
        readout = LDAReadout(
            include_polarization=True,
            hidden_sizes=(),
        ).to(dtype=torch.float64)
        with torch.no_grad():
            readout.mlp[0].weight.copy_(
                torch.tensor([[0.0, -100.0, 0.0]], dtype=torch.float64)
            )
            readout.mlp[0].bias.zero_()
        model = GridCACEModel(
            a_features=None,
            b_features=None,
            readout=[readout],
            ideal=FixedDipoleIdeal(1.0),
            polarization_scale=.5,
            grid_spacing=1.0,
            mean_temperature=1.0,
            compute_c1=False,
            mean_density=0.5,
        ).to(dtype=torch.float64)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            variable="dipole_density",
            include_zero_wavevector=False,
        )

        value = term(model(batch, compute_c1=False), batch, model=model)
        value.backward()

        self.assertGreater(value.item(), 1.0)
        self.assertTrue(torch.all(torch.isfinite(readout.mlp[0].weight.grad)))
        self.assertNotEqual(readout.mlp[0].weight.grad[0, 1].item(), 0.0)

    def test_unstable_curvature_is_penalized_and_differentiable(self):
        batch = self._batch()
        model = _QuadraticExcessModel(-4.0).to(dtype=torch.float64)
        outputs = model(batch)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
        )

        value = term(outputs, batch, model=model)
        value.backward()

        self.assertGreater(value.item(), 0.9)
        self.assertLess(value.item(), 1.1)
        self.assertIsNotNone(model.coefficient.grad)
        self.assertTrue(torch.isfinite(model.coefficient.grad).item())
        self.assertNotEqual(model.coefficient.grad.item(), 0.0)

    def test_perturbations_preserve_particle_number(self):
        batch = self._batch()
        batch["rho"] = torch.cat(
            (batch["rho"], 0.5 * batch["rho"]),
            dim=-1,
        )
        model = _QuadraticExcessModel(-4.0).to(dtype=torch.float64)
        outputs = model(batch)
        term = FourierStabilityLoss(wavevector_indices=((1, 0, 0), (2, 0, 0)))

        term(outputs, batch, model=model)

        reference_sum = batch["rho"].sum(dim=-2)
        perturbed_sums = model.last_rho.sum(dim=-2)
        self.assertTrue(
            torch.allclose(
                perturbed_sums,
                reference_sum[:, None, :].expand_as(perturbed_sums),
                atol=1.0e-12,
                rtol=0.0,
            )
        )

    def test_multicomponent_loss_averages_independent_component_curvatures(self):
        batch = self._batch()
        batch["rho"] = torch.cat(
            (batch["rho"], 0.5 * batch["rho"]),
            dim=-1,
        )
        model = _QuadraticExcessModel(-8.0).to(dtype=torch.float64)
        outputs = model(batch)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
        )

        value = term(outputs, batch, model=model)
        value.backward()

        # For this local quadratic functional, the two normalized component
        # curvatures are 1 + rho_a * coefficient = -3 and -1. Their squared
        # stability hinges therefore average to (9 + 1) / 2 = 5.
        self.assertAlmostEqual(value.item(), 5.0, places=3)
        self.assertIsNotNone(model.coefficient.grad)

    def test_total_density_and_charge_construct_coupled_directions(self):
        batch = self._batch()
        batch["rho"] = torch.cat((batch["rho"], batch["rho"]), dim=-1)

        total = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            component_treatment="total_density",
        )._component_weights(2, batch["rho"])
        charge = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            component_treatment="charge",
            charges=(1.0, -1.0),
        )._component_weights(2, batch["rho"])

        self.assertTrue(torch.equal(total, torch.tensor([[1.0, 1.0]])))
        self.assertTrue(torch.equal(charge, torch.tensor([[1.0, -1.0]])))

    def test_charge_mode_detects_unstable_coupled_charge_curvature(self):
        batch = self._batch()
        batch["rho"] = torch.cat((batch["rho"], batch["rho"]), dim=-1)
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])
        outputs = model(batch)

        independent = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
            component_treatment="independent",
        )(outputs, batch, model=model)
        total_density = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
            component_treatment="total_density",
        )(outputs, batch, model=model)
        charge = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
            component_treatment="charge",
            charges=(1.0, -1.0),
        )(outputs, batch, model=model)

        self.assertEqual(independent.item(), 0.0)
        self.assertEqual(total_density.item(), 0.0)
        self.assertGreater(charge.item(), 0.2)

    def test_full_matrix_detects_instability_missed_by_fixed_directions(self):
        batch = self._batch()
        batch["rho"] = torch.cat((batch["rho"], batch["rho"]), dim=-1)
        # Including the ideal term, this produces K=[[4.6,1.5],[1.5,0.4]].
        # Its physical-component, number, and charge diagonal projections are
        # all positive, but its determinant is negative.
        model = _CoupledQuadraticExcessModel([[7.2, 3.0], [3.0, -1.2]])
        outputs = model(batch)
        common = {
            "wavevector_indices": ((1, 0, 0),),
            "relative_amplitude": 2.0**-10,
        }

        independent = FourierStabilityLoss(
            **common,
            component_treatment="independent",
        )(outputs, batch, model=model)
        total_density = FourierStabilityLoss(
            **common,
            component_treatment="total_density",
        )(outputs, batch, model=model)
        charge = FourierStabilityLoss(
            **common,
            component_treatment="charge",
            charges=(1.0, -1.0),
        )(outputs, batch, model=model)
        full_matrix = FourierStabilityLoss(
            **common,
            component_treatment="full_matrix",
        )(outputs, batch, model=model)
        full_matrix.backward()

        self.assertEqual(independent.item(), 0.0)
        self.assertEqual(total_density.item(), 0.0)
        self.assertEqual(charge.item(), 0.0)
        self.assertGreater(full_matrix.item(), 1.0e-3)
        self.assertTrue(torch.all(torch.isfinite(model.matrix.grad)))
        self.assertNotEqual(torch.count_nonzero(model.matrix.grad).item(), 0)

    def test_full_matrix_perturbations_preserve_every_particle_number(self):
        batch = self._batch()
        batch["rho"] = torch.cat(
            (batch["rho"], 0.5 * batch["rho"]),
            dim=-1,
        )
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            component_treatment="full_matrix",
        )

        term(model(batch), batch, model=model)

        reference = batch["rho"].sum(dim=-2)
        perturbed = model.last_rho.sum(dim=-2)
        self.assertTrue(
            torch.allclose(
                perturbed,
                reference[:, None, :].expand_as(perturbed),
                atol=1.0e-12,
                rtol=0.0,
            )
        )

    def test_coupled_modes_preserve_every_component_particle_number(self):
        batch = self._batch()
        batch["rho"] = torch.cat((batch["rho"], 0.5 * batch["rho"]), dim=-1)
        reference_sum = batch["rho"].sum(dim=-2)

        for component_treatment, charges in (
            ("total_density", None),
            ("charge", (2.0, -1.0)),
        ):
            with self.subTest(component_treatment=component_treatment):
                model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
                term = FourierStabilityLoss(
                    wavevector_indices=((1, 0, 0),),
                    component_treatment=component_treatment,
                    charges=charges,
                )
                term(model(batch), batch, model=model)
                perturbed_sums = model.last_rho.sum(dim=-2)
                self.assertTrue(
                    torch.allclose(
                        perturbed_sums,
                        reference_sum[:, None, :].expand_as(perturbed_sums),
                        atol=1.0e-12,
                        rtol=0.0,
                    )
                )

    def test_multicomponent_loss_integrates_with_grid_model(self):
        batch = self._batch()
        batch["rho"] = torch.cat(
            (batch["rho"], 0.5 * batch["rho"]),
            dim=-1,
        )
        readout = LDAReadout(
            n_types=2,
            hidden_sizes=(),
        ).to(dtype=torch.float64)
        with torch.no_grad():
            readout.mlp[-1].weight.copy_(
                torch.tensor([[-4.0, -4.0, 0.0]], dtype=torch.float64)
            )
            readout.mlp[-1].bias.zero_()
        model = GridCACEModel(
            a_features=None,
            b_features=None,
            readout=[readout],
            grid_spacing=1.0,
            compute_c1=False,
            free_energy_mode="beta",
            mean_density=1.0,
        ).to(dtype=torch.float64)
        outputs = model(batch, compute_c1=False)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
        )

        value = term(outputs, batch, model=model)
        value.backward()

        self.assertAlmostEqual(value.item(), 5.0, places=3)
        self.assertTrue(torch.all(torch.isfinite(readout.mlp[-1].weight.grad)))

    def test_full_matrix_integrates_with_grid_model(self):
        batch = self._batch()
        batch["rho"] = torch.cat(
            (batch["rho"], 0.5 * batch["rho"]),
            dim=-1,
        )
        readout = LDAReadout(
            n_types=2,
            hidden_sizes=(),
        ).to(dtype=torch.float64)
        with torch.no_grad():
            readout.mlp[-1].weight.copy_(
                torch.tensor([[-4.0, -4.0, 0.0]], dtype=torch.float64)
            )
            readout.mlp[-1].bias.zero_()
        model = GridCACEModel(
            a_features=None,
            b_features=None,
            readout=[readout],
            grid_spacing=1.0,
            compute_c1=False,
            free_energy_mode="beta",
            mean_density=1.0,
        ).to(dtype=torch.float64)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
            component_treatment="full_matrix",
        )

        value = term(model(batch, compute_c1=False), batch, model=model)
        value.backward()

        # The linear per-particle LDA gives F_exc=-4*(rho_1+rho_2)^2.
        # At densities (0.5,0.25), the ideal-metric Hessian eigenvalues are
        # (1,-5), so the mean squared stability hinge is 25/2.
        self.assertAlmostEqual(value.item(), 12.5, places=3)
        self.assertTrue(torch.all(torch.isfinite(readout.mlp[-1].weight.grad)))

    def test_absent_component_is_excluded_from_average(self):
        batch = self._batch()
        batch["rho"] = torch.cat(
            (batch["rho"], torch.zeros_like(batch["rho"])),
            dim=-1,
        )
        model = _QuadraticExcessModel(-4.0).to(dtype=torch.float64)
        outputs = model(batch)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            relative_amplitude=0.01,
        )

        value = term(outputs, batch, model=model)

        self.assertAlmostEqual(value.item(), 1.0, places=3)

    def test_loss_aggregator_supplies_model(self):
        batch = self._batch()
        model = _QuadraticExcessModel(-4.0).to(dtype=torch.float64)
        outputs = model(batch)
        loss = Loss(
            [FourierStabilityLoss(wavevector_indices=((1, 0, 0),), weight=2.0)]
        )

        values = loss(outputs, batch, model=model)

        self.assertEqual(list(values), ["fourier_stability", "total"])
        self.assertAlmostEqual(
            values["total"].item(),
            values["fourier_stability"].item(),
        )

    def test_nyquist_cosine_is_kept_and_zero_alias_is_rejected(self):
        batch = self._batch(dtype=torch.float32)
        model = _QuadraticExcessModel(0.0)
        outputs = model(batch)

        value = FourierStabilityLoss(wavevector_indices=((4, 0, 0),))(
            outputs,
            batch,
            model=model,
        )
        self.assertEqual(value.item(), 0.0)
        with self.assertRaisesRegex(ValueError, "Nyquist sphere"):
            FourierStabilityLoss(wavevector_indices=((8, 0, 0),))(
                outputs,
                batch,
                model=model,
            )

    def test_random_triplets_are_sampled_per_field_inside_nyquist_sphere(self):
        n_grid = 8
        positions = torch.tensor(
            [
                [x, y, z]
                for x in range(n_grid)
                for y in range(n_grid)
                for z in range(n_grid)
            ]
        )
        batch = {
            "rho": torch.full((2, n_grid**3, 1), 0.5),
            "temperature": torch.ones(2),
            "grid_spacing": torch.ones(2, 3),
            "grid_size": torch.tensor([[n_grid] * 3] * 2),
            "grid_positions": positions[None].expand(2, -1, -1),
        }
        term = FourierStabilityLoss(random_wavevectors_per_field=3)
        torch.manual_seed(11)

        modes = term._select_wavevector_indices(batch, batch["rho"])

        self.assertEqual(modes.shape, (2, 3, 3))
        scaled_squared_norm = torch.sum(
            (2.0 * modes.to(torch.float32) / n_grid) ** 2,
            dim=-1,
        )
        self.assertTrue(
            torch.all(scaled_squared_norm <= 1.0 + 1.0e-6).item()
        )
        self.assertTrue(torch.all(torch.any(modes != 0, dim=-1)).item())

    def test_random_triplets_can_be_restricted_by_wavevector_range(self):
        n_grid = 8
        positions = torch.tensor(
            [
                [x, y, z]
                for x in range(n_grid)
                for y in range(n_grid)
                for z in range(n_grid)
            ]
        )
        batch = {
            "rho": torch.full((2, n_grid**3, 1), 0.5),
            "temperature": torch.ones(2),
            "grid_spacing": torch.ones(2, 3),
            "grid_size": torch.tensor([[n_grid] * 3] * 2),
            "grid_positions": positions[None].expand(2, -1, -1),
        }
        term = FourierStabilityLoss(
            random_wavevectors_per_field=3,
            wavevector_range=(1.5, 1.6),
        )
        torch.manual_seed(11)

        modes = term._select_wavevector_indices(batch, batch["rho"])
        wavevectors = 2.0 * torch.pi * modes.to(torch.float32) / n_grid
        magnitudes = torch.linalg.vector_norm(wavevectors, dim=-1)

        self.assertEqual(modes.shape, (2, 3, 3))
        self.assertTrue(torch.all(magnitudes >= 1.5).item())
        self.assertTrue(torch.all(magnitudes <= 1.6).item())

    def test_anisotropic_spacing_uses_physical_nyquist_sphere(self):
        modes = set(_feasible_wavevector_indices((8, 8, 8), (0.5, 1.0, 1.0)))

        # The x direction has a larger axis-specific Nyquist limit, but the
        # isotropically complete sphere is limited by y and z to k <= pi.
        self.assertIn((2, 0, 0), modes)
        self.assertNotIn((4, 0, 0), modes)
        for mode in modes:
            wavevector = torch.tensor(
                [
                    2.0 * torch.pi * index / (size * spacing)
                    for index, size, spacing in zip(
                        mode,
                        (8, 8, 8),
                        (0.5, 1.0, 1.0),
                    )
                ]
            )
            self.assertLessEqual(
                torch.linalg.vector_norm(wavevector).item(),
                torch.pi + 1.0e-6,
            )

    def test_training_only_random_loss_is_zero_during_validation(self):
        batch = self._batch()
        model = _QuadraticExcessModel(-4.0).to(dtype=torch.float64)
        outputs = model(batch)
        term = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0),),
            training_only=True,
        ).eval()

        value = term(outputs, batch, model=model)

        self.assertEqual(value.item(), 0.0)

    def test_configuration_and_scope_are_validated(self):
        with self.assertRaisesRegex(TypeError, "positional"):
            FourierStabilityLoss(((1, 0, 0),))
        with self.assertRaisesRegex(ValueError, "exactly one"):
            FourierStabilityLoss()
        with self.assertRaisesRegex(ValueError, "variable"):
            FourierStabilityLoss(wavevector_indices=((1, 0, 0),), variable="unknown")
        with self.assertRaisesRegex(ValueError, "zero wavevector"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                include_zero_wavevector=True,
            )
        for invalid_treatment in ("", "unknown"):
            with self.assertRaisesRegex(ValueError, "wavevector_treatment"):
                FourierStabilityLoss(
                    wavevector_indices=((1, 0, 0),),
                    wavevector_treatment=invalid_treatment,
                )
        with self.assertRaisesRegex(TypeError, "wavevector_treatment"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                wavevector_treatment=1,
            )
        with self.assertRaisesRegex(ValueError, "requires component_treatment='independent'"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                variable="dipole_density",
                component_treatment="full_matrix",
            )
        for modes in ((), ((0, 0, 0),), ((1.5, 0, 0),)):
            with self.subTest(wavevector_indices=modes):
                with self.assertRaises(ValueError):
                    FourierStabilityLoss(wavevector_indices=modes)
        with self.assertRaisesRegex(ValueError, "relative_amplitude"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                relative_amplitude=1.0,
            )
        with self.assertRaisesRegex(ValueError, "random_wavevectors_per_field"):
            FourierStabilityLoss(random_wavevectors_per_field=0)
        with self.assertRaisesRegex(ValueError, "exactly one"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                random_wavevectors_per_field=1,
            )
        for wavevector_range in (
            1.0,
            (),
            (1.0,),
            (0.0, 1.0, 2.0),
            (-1.0, 2.0),
            (2.0, 1.0),
            (0.0, 0.0),
            (0.0, float("inf")),
        ):
            with self.subTest(wavevector_range=wavevector_range):
                with self.assertRaisesRegex(ValueError, "wavevector_range"):
                    FourierStabilityLoss(
                        random_wavevectors_per_field=1,
                        wavevector_range=wavevector_range,
                    )
        with self.assertRaisesRegex(ValueError, "cannot be combined"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                wavevector_range=(0.5, 1.5),
            )
        with self.assertRaisesRegex(ValueError, "wavevector_range"):
            term = FourierStabilityLoss(
                random_wavevectors_per_field=1,
                wavevector_range=(0.1, 0.2),
            )
            batch = self._batch()
            term._select_wavevector_indices(batch, batch["rho"])

        with self.assertRaisesRegex(ValueError, "component_treatment"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                component_treatment="unknown",
            )
        with self.assertRaisesRegex(ValueError, "required"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                component_treatment="charge",
            )
        with self.assertRaisesRegex(ValueError, "require charge"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                component_treatment="total_density",
                charges=(1.0,),
            )
        with self.assertRaisesRegex(ValueError, "require charge"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                component_treatment="full_matrix",
                charges=(1.0,),
            )
        with self.assertRaisesRegex(ValueError, "perturbations_per_forward"):
            FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                component_treatment="full_matrix",
                perturbations_per_forward=0,
            )
        with self.assertRaisesRegex(ValueError, "one value per density type"):
            term = FourierStabilityLoss(
                wavevector_indices=((1, 0, 0),),
                component_treatment="charge",
                charges=(1.0, -1.0),
            )
            batch = self._batch()
            model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
            term(model(batch), batch, model=model)
        batch = self._batch()
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        del batch["grid_size"]
        with self.assertRaisesRegex(KeyError, "grid_size"):
            FourierStabilityLoss(wavevector_indices=((1, 0, 0),))(
                model(batch),
                batch,
                model=model,
            )

    def test_explicit_wavevectors_share_canonical_grid_validation(self):
        batch = self._batch()
        term = FourierStabilityLoss(wavevector_indices=((-1, 0, 0),))

        selected = term._select_wavevector_indices(batch, batch["rho"])

        self.assertTrue(
            torch.equal(selected, torch.tensor([[[1, 0, 0]]]))
        )
        duplicate = FourierStabilityLoss(
            wavevector_indices=((1, 0, 0), (-1, 0, 0))
        )
        with self.assertRaisesRegex(ValueError, "equivalent"):
            duplicate._select_wavevector_indices(batch, batch["rho"])

    def test_wavevector_selection_validates_complete_grid_geometry(self):
        term = FourierStabilityLoss(wavevector_indices=((1, 0, 0),))
        cases = (
            ("grid_size", [[0, 1, 1]], "positive integers"),
            ("grid_size", [[4, 1, 1]], "number of grid points"),
            ("grid_spacing", [[0.0, 1.0, 1.0]], "finite positive"),
            (
                "grid_spacing",
                [[float("nan"), 1.0, 1.0]],
                "finite positive",
            ),
        )
        for key, value, message in cases:
            batch = self._batch()
            batch[key] = torch.tensor(value, dtype=batch[key].dtype)
            with self.subTest(key=key, value=value):
                with self.assertRaisesRegex(ValueError, message):
                    term._select_wavevector_indices(batch, batch["rho"])


class TestFourierResponseLoss(unittest.TestCase):
    @staticmethod
    def _batch(dtype=torch.float64, n_types=1, n_modes=2):
        batch = TestFourierStabilityLoss._batch(dtype=dtype)
        if n_types == 2:
            batch["rho"] = torch.cat((batch["rho"], batch["rho"]), dim=-1)
        modes = ((1, 0, 0), (2, 0, 0))[:n_modes]
        batch["fourier_wavevector_indices"] = torch.tensor([modes])
        return batch

    def test_ideal_gas_matches_unit_inverse_response(self):
        batch = self._batch()
        batch["fourier_curvature"] = torch.ones((1, 2, 1), dtype=torch.float64)
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        term = FourierResponseLoss(
            directions=((1.0,),),
            relative_amplitude=1.0e-4,
        )

        value = term(model(batch), batch, model=model)

        self.assertLess(
            value.item(),
            10.0 * torch.finfo(torch.float64).eps,
        )

    def test_response_validates_grid_geometry_before_mode_evaluation(self):
        term = FourierResponseLoss(
            directions=((1.0,),),
            relative_amplitude=1.0e-4,
        )
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        for key, value, message in (
            ("grid_size", [[4, 1, 1]], "number of grid points"),
            (
                "grid_spacing",
                [[1.0, float("inf"), 1.0]],
                "finite.*positive",
            ),
        ):
            batch = self._batch(n_modes=1)
            batch["fourier_curvature"] = torch.ones(
                (1, 1, 1),
                dtype=torch.float64,
            )
            batch[key] = torch.tensor(value, dtype=batch[key].dtype)
            with self.subTest(key=key):
                with self.assertRaisesRegex(ValueError, message):
                    term(model(batch), batch, model=model)

    def test_response_mismatch_is_penalized_and_differentiable(self):
        batch = self._batch(n_modes=1)
        batch["fourier_curvature"] = torch.ones((1, 1, 1), dtype=torch.float64)
        model = _QuadraticExcessModel(2.0).to(dtype=torch.float64)
        term = FourierResponseLoss(
            directions=((1.0,),),
            relative_amplitude=1.0e-4,
        )

        value = term(model(batch), batch, model=model)
        value.backward()

        # K = 1 + rho * coefficient = 2. Smooth L1(2, 1) = 0.5.
        self.assertAlmostEqual(value.item(), 0.5, places=6)
        self.assertIsNotNone(model.coefficient.grad)
        self.assertNotEqual(model.coefficient.grad.item(), 0.0)

    def test_mixture_number_and_charge_targets_use_full_hessian(self):
        batch = self._batch(n_types=2, n_modes=1)
        batch["fourier_curvature"] = torch.tensor(
            [[[2.5, -0.5]]],
            dtype=torch.float64,
        )
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])
        term = FourierResponseLoss(
            directions=((1.0, 1.0), (1.0, -1.0)),
            # A power-of-two amplitude avoids decimal-representation noise
            # in this strict float64 roundoff test.
            relative_amplitude=2.0**-13,
        )

        value = term(model(batch), batch, model=model)

        self.assertLess(
            value.item(),
            10.0 * torch.finfo(torch.float64).eps,
        )

    def test_shared_response_returns_phase_resolved_curvature(self):
        batch = self._batch(n_types=2, n_modes=1)
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])
        response = FourierResponse(relative_amplitude=1.0e-4)

        curvature, valid = response(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            directions=torch.tensor(
                ((1.0, 1.0), (1.0, -1.0)),
                dtype=torch.float64,
            ),
            outputs=model(batch),
        )

        self.assertEqual(curvature.shape, (1, 1, 2, 2))
        self.assertTrue(torch.all(valid).item())
        expected = torch.tensor((2.5, -0.5), dtype=torch.float64)
        self.assertTrue(
            torch.allclose(curvature[0, 0], expected.expand(2, -1))
        )

    def test_shared_response_returns_full_inverse_response_matrix(self):
        batch = self._batch(n_types=2, n_modes=1)
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])
        response = FourierResponse(relative_amplitude=2.0**-10)

        matrix, active = response.matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        expected = torch.tensor(
            [[1.0, 1.5], [1.5, 1.0]],
            dtype=torch.float64,
        )
        self.assertEqual(matrix.shape, (1, 1, 2, 2, 2))
        self.assertTrue(torch.all(active).item())
        self.assertTrue(
            torch.allclose(
                matrix[0, 0],
                expected.expand(2, -1, -1),
                atol=2.0e-6,
                rtol=0.0,
            )
        )

    def test_full_matrix_recovers_three_component_hessian(self):
        batch = self._batch(n_modes=1)
        densities = torch.tensor((0.5, 0.25, 0.75), dtype=torch.float64)
        batch["rho"] = densities.expand(1, 8, -1).clone()
        excess = torch.tensor(
            (
                (0.2, 0.3, -0.1),
                (0.3, -0.4, 0.5),
                (-0.1, 0.5, 0.7),
            ),
            dtype=torch.float64,
        )
        model = _CoupledQuadraticExcessModel(excess)

        matrix, active = FourierResponse(
            relative_amplitude=2.0**-10,
        ).matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        root_density = torch.sqrt(densities)
        expected = torch.eye(3, dtype=torch.float64) + (
            root_density[:, None] * excess * root_density[None, :]
        )
        self.assertTrue(torch.all(active).item())
        self.assertTrue(
            torch.allclose(
                matrix[0, 0],
                expected.expand(2, -1, -1),
                atol=2.0e-6,
                rtol=0.0,
            )
        )

    def test_projected_response_is_a_matrix_rayleigh_quotient(self):
        batch = self._batch(n_types=2, n_modes=1)
        densities = torch.tensor((0.5, 0.25), dtype=torch.float64)
        batch["rho"] = densities.expand(1, 8, -1).clone()
        model = _CoupledQuadraticExcessModel([[0.2, 0.3], [0.3, -0.4]])
        response = FourierResponse(relative_amplitude=2.0**-10)
        weights = torch.tensor(((1.0, -0.7),), dtype=torch.float64)

        curvature, valid = response(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            directions=weights,
            outputs=model(batch),
        )
        matrix, active = response.matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        direction = torch.sqrt(densities) * weights[0]
        rayleigh = torch.einsum(
            "i,...ij,j->...",
            direction,
            matrix,
            direction,
        ) / torch.dot(direction, direction)
        self.assertTrue(torch.all(valid).item())
        self.assertTrue(torch.all(active).item())
        self.assertTrue(
            torch.allclose(
                curvature[..., 0],
                rayleigh,
                atol=2.0e-6,
                rtol=0.0,
            )
        )

    def test_full_matrix_ideal_metric_handles_unequal_nonuniform_densities(self):
        batch = self._batch(n_types=2, n_modes=1)
        profile = torch.linspace(0.2, 0.8, 8, dtype=torch.float64)
        batch["rho"] = torch.stack(
            (profile, 0.7 * torch.flip(profile, dims=(0,))),
            dim=-1,
        )[None]
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        response = FourierResponse(relative_amplitude=2.0**-10)

        matrix, active = response.matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        expected = torch.eye(2, dtype=torch.float64).expand(2, -1, -1)
        self.assertTrue(torch.all(active).item())
        self.assertTrue(
            torch.allclose(
                matrix[0, 0],
                expected,
                atol=2.0e-6,
                rtol=0.0,
            )
        )

    def test_full_matrix_excludes_absent_components(self):
        batch = self._batch(n_types=2, n_modes=1)
        batch["rho"][..., 1].zero_()
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)

        matrix, active = FourierResponse(
            relative_amplitude=2.0**-10,
        ).matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        self.assertTrue(torch.all(active[..., 0]).item())
        self.assertFalse(torch.any(active[..., 1]).item())
        self.assertTrue(torch.all(matrix[..., 1, :] == 0.0).item())
        self.assertTrue(torch.all(matrix[..., :, 1] == 0.0).item())
        self.assertTrue(
            torch.allclose(
                matrix[..., 0, 0],
                torch.ones_like(matrix[..., 0, 0]),
                atol=2.0e-6,
                rtol=0.0,
            )
        )

    def test_full_matrix_nyquist_excludes_only_the_aliased_phase(self):
        batch = self._batch(n_types=2, n_modes=1)
        batch["fourier_wavevector_indices"] = torch.tensor([[[4, 0, 0]]])
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)

        matrix, active = FourierResponse(
            relative_amplitude=2.0**-10,
        ).matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        self.assertTrue(torch.all(active[:, :, 0]).item())
        self.assertFalse(torch.any(active[:, :, 1]).item())
        self.assertTrue(torch.all(matrix[:, :, 1] == 0.0).item())

    def test_full_matrix_chunking_matches_single_forward(self):
        batch = self._batch(n_types=2, n_modes=1)
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])

        unchunked = FourierResponse(relative_amplitude=2.0**-10).matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )
        chunked = FourierResponse(
            relative_amplitude=2.0**-10,
            perturbations_per_forward=2,
        ).matrix(
            model=model,
            batch=batch,
            wavevector_indices=batch["fourier_wavevector_indices"],
            outputs=model(batch),
        )

        self.assertTrue(torch.equal(unchunked[1], chunked[1]))
        self.assertTrue(
            torch.allclose(unchunked[0], chunked[0], atol=1.0e-12, rtol=0.0)
        )

    def test_perturbations_can_be_evaluated_in_small_forward_chunks(self):
        batch = self._batch(n_types=2, n_modes=1)
        batch["fourier_curvature"] = torch.tensor(
            [[[2.5, -0.5]]],
            dtype=torch.float64,
        )
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])

        unchunked = FourierResponseLoss(
            directions=((1.0, 1.0), (1.0, -1.0)),
            relative_amplitude=1.0e-4,
        )(model(batch), batch, model=model)
        chunked = FourierResponseLoss(
            directions=((1.0, 1.0), (1.0, -1.0)),
            relative_amplitude=1.0e-4,
            perturbations_per_forward=2,
        )(model(batch), batch, model=model)

        self.assertAlmostEqual(chunked.item(), unchunked.item(), places=15)

    def test_direction_common_scale_is_immaterial(self):
        batch = self._batch(n_types=2, n_modes=1)
        batch["fourier_curvature"] = torch.tensor(
            [[[2.5]]],
            dtype=torch.float64,
        )
        model = _CoupledQuadraticExcessModel([[0.0, 3.0], [3.0, 0.0]])

        unit = FourierResponseLoss(
            directions=((1.0, 1.0),),
            relative_amplitude=1.0e-4,
        )(
            model(batch), batch, model=model
        )
        scaled = FourierResponseLoss(
            directions=((7.0, 7.0),),
            relative_amplitude=1.0e-4,
        )(
            model(batch), batch, model=model
        )

        self.assertAlmostEqual(unit.item(), scaled.item(), places=15)

    def test_scale_and_element_weights_are_applied_before_reduction(self):
        batch = self._batch()
        batch["fourier_curvature"] = torch.tensor(
            [[[1.0], [8.0]]],
            dtype=torch.float64,
        )
        batch["response_scale"] = torch.tensor(
            [[[1.0], [2.0]]],
            dtype=torch.float64,
        )
        batch["response_weight"] = torch.tensor(
            [[[1.0], [3.0]]],
            dtype=torch.float64,
        )
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        term = FourierResponseLoss(
            directions=((1.0,),),
            scale_key="response_scale",
            weights_key="response_weight",
            loss_fn=_TargetValueLoss(),
            relative_amplitude=1.0e-4,
        )

        value = term(model(batch), batch, model=model)

        # The custom element loss returns scaled targets 1 and 4. Their
        # weighted mean is (1 + 3*4) / 4.
        self.assertAlmostEqual(value.item(), 3.25, places=12)

    def test_evaluate_exposes_raw_responses_without_recomputation(self):
        batch = self._batch(n_modes=1)
        batch["fourier_curvature"] = torch.tensor(
            [[[1.0]]], dtype=torch.float64
        )
        batch["response_scale"] = torch.tensor(
            [[[4.0]]], dtype=torch.float64
        )
        batch["response_weight"] = torch.tensor(
            [[[3.0]]], dtype=torch.float64
        )
        model = _QuadraticExcessModel(2.0).to(dtype=torch.float64)
        term = FourierResponseLoss(
            directions=((1.0,),),
            scale_key="response_scale",
            weights_key="response_weight",
            relative_amplitude=1.0e-4,
        )

        details = term.evaluate(model(batch), batch, model=model)

        self.assertAlmostEqual(details["loss"].item(), 0.03125, places=6)
        self.assertAlmostEqual(details["prediction"].item(), 2.0, places=6)
        self.assertAlmostEqual(details["target"].item(), 1.0, places=12)
        self.assertAlmostEqual(details["scale"].item(), 4.0, places=12)
        self.assertAlmostEqual(details["element_weight"].item(), 3.0, places=12)

    def test_nyquist_uses_the_single_nonaliased_real_phase(self):
        batch = self._batch(dtype=torch.float64, n_modes=1)
        batch["fourier_wavevector_indices"] = torch.tensor([[[4, 0, 0]]])
        batch["fourier_curvature"] = torch.ones((1, 1, 1), dtype=torch.float64)
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)

        value = FourierResponseLoss(
            directions=((1.0,),),
            relative_amplitude=1.0e-4,
        )(
            model(batch), batch, model=model
        )

        self.assertLess(
            value.item(),
            10.0 * torch.finfo(torch.float64).eps,
        )

    def test_loss_aggregator_supplies_model(self):
        batch = self._batch(n_modes=1)
        batch["fourier_curvature"] = torch.ones((1, 1, 1), dtype=torch.float64)
        model = _QuadraticExcessModel(2.0).to(dtype=torch.float64)
        loss = Loss(
            [
                FourierResponseLoss(
                    directions=((1.0,),),
                    relative_amplitude=1.0e-4,
                    weight=2.0,
                )
            ]
        )

        values = loss(model(batch), batch, model=model)

        self.assertEqual(list(values), ["fourier_response", "total"])
        self.assertAlmostEqual(values["total"].item(), 1.0, places=6)

    def test_configuration_and_batch_contract_are_validated(self):
        for directions in ((), ((0.0,),), ((float("nan"),),)):
            with self.subTest(directions=directions):
                with self.assertRaises(ValueError):
                    FourierResponseLoss(directions=directions)
        with self.assertRaisesRegex(ValueError, "relative_amplitude"):
            FourierResponseLoss(((1.0,),), relative_amplitude=0.0)
        with self.assertRaisesRegex(TypeError, "loss_fn"):
            FourierResponseLoss(((1.0,),), loss_fn=lambda x, y: x - y)
        with self.assertRaisesRegex(ValueError, "perturbations_per_forward"):
            FourierResponseLoss(((1.0,),), perturbations_per_forward=0)

        batch = self._batch(n_modes=1)
        batch["fourier_curvature"] = torch.ones((1, 1, 1), dtype=torch.float64)
        model = _QuadraticExcessModel(0.0).to(dtype=torch.float64)
        term = FourierResponseLoss(((1.0,),))

        nonuniform = {key: value.clone() for key, value in batch.items()}
        nonuniform["rho"][0, 0, 0] = 0.6
        with self.assertRaisesRegex(ValueError, "spatially uniform"):
            term(model(nonuniform), nonuniform, model=model)

        zero_mode = {key: value.clone() for key, value in batch.items()}
        zero_mode["fourier_wavevector_indices"].zero_()
        with self.assertRaisesRegex(ValueError, "zero wavevector"):
            term(model(zero_mode), zero_mode, model=model)

        for value, message in (
            (1.5, "integers"),
            (float("nan"), "finite"),
        ):
            invalid_mode = {
                key: value.clone() for key, value in batch.items()
            }
            invalid_mode["fourier_wavevector_indices"] = torch.tensor(
                [[[value, 0.0, 0.0]]], dtype=torch.float64
            )
            with self.subTest(mode=value):
                with self.assertRaisesRegex(ValueError, message):
                    term(model(invalid_mode), invalid_mode, model=model)

        wrong_target = {key: value.clone() for key, value in batch.items()}
        wrong_target["fourier_curvature"] = torch.ones((1, 1))
        with self.assertRaisesRegex(ValueError, "n_directions"):
            term(model(wrong_target), wrong_target, model=model)


class TestLossAggregation(unittest.TestCase):
    def test_aggregates_named_weighted_terms(self):
        c1_prediction = torch.tensor([1.0, 3.0], requires_grad=True)
        energy_prediction = torch.tensor([3.0], requires_grad=True)
        loss = Loss(
            [
                TensorLoss(
                    "c1",
                    "c1",
                    "c1",
                    loss_fn=nn.MSELoss(),
                    weight=2.0,
                ),
                TensorLoss(
                    "free_energy",
                    "beta_F_exc",
                    "beta_F_exc",
                    loss_fn=nn.L1Loss(),
                    weight=0.5,
                ),
            ]
        )
        values = loss(
            {"c1": c1_prediction, "beta_F_exc": energy_prediction},
            {
                "c1": torch.tensor([0.0, 1.0]),
                "beta_F_exc": torch.tensor([1.0]),
            },
        )
        values["total"].backward()
        self.assertEqual(list(values), ["c1", "free_energy", "total"])
        self.assertAlmostEqual(values["c1"].item(), 5.0)
        self.assertAlmostEqual(values["free_energy"].item(), 1.0)
        self.assertAlmostEqual(values["total"].item(), 6.0)
        self.assertIsNotNone(c1_prediction.grad)
        self.assertIsNotNone(energy_prediction.grad)

    def test_accepts_specialized_term_with_same_interface(self):
        loss = Loss([_PredictionPenalty()])
        values = loss({"c1": torch.tensor([-2.0, 4.0])}, {})
        self.assertAlmostEqual(values["prediction_penalty"].item(), 3.0)
        self.assertAlmostEqual(values["total"].item(), 3.0)

        values, details = loss.evaluate(
            {"c1": torch.tensor([-2.0, 4.0])}, {}, model=nn.Identity(),
        )
        self.assertEqual(set(details), {"prediction_penalty"})
        self.assertTrue(details["prediction_penalty"]["model_seen"])
        self.assertAlmostEqual(details["prediction_penalty"]["loss"].item(), 3.0)

    def test_plain_modules_are_rejected_and_terms_expose_details(self):
        with self.assertRaisesRegex(TypeError, "LossTerm"):
            Loss([_UnnamedTerm()])
        term = TensorLoss("c1", "c1", "c1", weight=2.0)
        self.assertIsInstance(term, LossTerm)
        outputs = {"c1": torch.tensor([1.0, 3.0])}
        batch = {"c1": torch.tensor([0.0, 1.0])}
        details = term.evaluate(outputs, batch)
        self.assertEqual(set(details), {"loss"})
        torch.testing.assert_close(details["loss"], term(outputs, batch, model=None))
        with self.assertRaisesRegex(ValueError, "nonempty"):
            TensorLoss("", "c1", "c1")
        with self.assertRaisesRegex(ValueError, "weight"):
            TensorLoss("c1", "c1", "c1", weight=-1.0)

    def test_terms_must_be_nonempty_named_and_unique(self):
        with self.assertRaisesRegex(ValueError, "at least one"):
            Loss([])
        with self.assertRaisesRegex(ValueError, "unique"):
            Loss(
                [
                    TensorLoss("c1", "c1", "c1"),
                    TensorLoss("c1", "c1_other", "c1_other"),
                ]
            )
        with self.assertRaisesRegex(ValueError, "reserved"):
            Loss([TensorLoss("total", "c1", "c1")])


if __name__ == "__main__":
    unittest.main()
