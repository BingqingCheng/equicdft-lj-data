"""Symmetrized Cartesian features for the simple cubic grid.

The exact point symmetry used here consists of all axis permutations and
independent axis reflections. These 48 signed permutations preserve the
integer spherical stencil constructed by :func:`equicdft.stencil.make_stencil`.
"""

from itertools import combinations_with_replacement, permutations, product
from typing import Any, Dict, List, Sequence, Tuple

import torch
from torch import nn

from .._validation import boolean, positive_integer
from .._config import Configurable, make_config, register
from .cartesian import _make_powers

__all__ = [
    "CartesianBFeatures",
]


def _make_group_actions(
    powers: torch.Tensor,
    include_polarization: bool = False,
    separate_center: bool = False,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Return the signed-permutation action on Cartesian monomials.

    For each of the 48 group elements and each monomial component ``k``, the
    returned tensors specify

    ``transformed_A[..., k, :] = sign[g, k] * A[..., index[g, k], :]``.
    """

    powers_list = [tuple(int(value) for value in row) for row in powers.tolist()]
    index_by_power = {power: index for index, power in enumerate(powers_list)}

    component_indices: List[List[int]] = []
    component_signs: List[List[int]] = []

    # output_axis i receives sign[i] * input_axis permutation[i].
    for permutation in permutations(range(3)):
        for reflections in product((1, -1), repeat=3):
            indices_now = []
            signs_now = []
            for power in powers_list:
                mapped_power = [0, 0, 0]
                sign = 1
                for output_axis, input_axis in enumerate(permutation):
                    mapped_power[input_axis] = power[output_axis]
                    sign *= reflections[output_axis] ** power[output_axis]
                indices_now.append(index_by_power[tuple(mapped_power)])
                signs_now.append(sign)
            if include_polarization:
                if separate_center:
                    # The unsmeared center is a distinct spatial-power-zero
                    # slot, not the smeared zeroth moment.
                    indices_now.append(len(powers_list))
                    signs_now.append(1)
                width = len(indices_now)
                spatial_indices, spatial_signs = indices_now, signs_now
                indices_now = list(spatial_indices)
                signs_now = list(spatial_signs)
                for axis in range(3):
                    indices_now.extend(
                        (permutation[axis] + 1) * width + k for k in spatial_indices
                    )
                    signs_now.extend(reflections[axis] * s for s in spatial_signs)
            component_indices.append(indices_now)
            component_signs.append(signs_now)

    return (
        torch.tensor(component_indices, dtype=torch.long),
        torch.tensor(component_signs, dtype=torch.get_default_dtype()),
    )


def _signed_orbit(
    indices: Tuple[int, ...],
    component_indices: Sequence[Sequence[int]],
    component_signs: Sequence[Sequence[int]],
) -> Tuple[Dict[Tuple[int, ...], int], bool]:
    """Generate one signed product orbit and report whether it vanishes."""

    terms: Dict[Tuple[int, ...], int] = {}
    vanishes = False
    for index_map, sign_map in zip(component_indices, component_signs):
        mapped_indices = tuple(sorted(index_map[index] for index in indices))
        mapped_sign = 1
        for index in indices:
            mapped_sign *= sign_map[index]

        previous_sign = terms.get(mapped_indices)
        if previous_sign is not None and previous_sign != mapped_sign:
            # A negative stabilizer pairs every term with its negative, so the
            # Reynolds average over this complete orbit is identically zero.
            vanishes = True
        terms[mapped_indices] = mapped_sign

    return terms, vanishes


def _make_product_recipes(
    n_components: int,
    max_product_order: int,
    component_indices: torch.Tensor,
    component_signs: torch.Tensor,
) -> Dict[int, Dict[str, torch.Tensor]]:
    """Build sparse signed orbit sums for correlation orders up to three."""

    index_maps = component_indices.tolist()
    sign_maps = component_signs.to(dtype=torch.long).tolist()
    recipes: Dict[int, Dict[str, torch.Tensor]] = {}

    for nu in range(1, max_product_order + 1):
        unseen = set(combinations_with_replacement(range(n_components), nu))
        product_indices: List[Tuple[int, ...]] = []
        coefficients: List[float] = []
        output_indices: List[int] = []
        representatives: List[Tuple[int, ...]] = []

        while unseen:
            representative = min(unseen)
            orbit, vanishes = _signed_orbit(
                representative,
                index_maps,
                sign_maps,
            )
            unseen.difference_update(orbit)
            if vanishes:
                continue

            output_index = len(representatives)
            representatives.append(representative)
            normalization = float(len(orbit))
            for term, sign in sorted(orbit.items()):
                product_indices.append(term)
                coefficients.append(sign / normalization)
                output_indices.append(output_index)

        recipes[nu] = {
            "product_indices": torch.tensor(product_indices, dtype=torch.long),
            "coefficients": torch.tensor(
                coefficients,
                dtype=torch.get_default_dtype(),
            ),
            "output_indices": torch.tensor(output_indices, dtype=torch.long),
            "representatives": torch.tensor(representatives, dtype=torch.long),
        }

    return recipes


@register
class CartesianBFeatures(nn.Module, Configurable):
    """Symmetrize Cartesian ``A`` features under cubic-grid point symmetry.

    Parameters
    ----------
    max_power
        Maximum total Cartesian power used by the corresponding
        :class:`equicdft.features.CartesianAFeatures` module.
    max_product_order
        Maximum correlation order, meaning the largest number of ``A``
        factors in one invariant product. Only values one through three are
        currently supported.
    include_polarization
        Extend the same signed-orbit construction to [rho, Px, Py, Pz]
        moment blocks. Both the spatial powers and polar-vector index
        transform. Mixed scalar/vector products are generated automatically,
        without a hand-written contraction list. Symmetry is cubic-grid O_h,
        not arbitrary continuous rotations.
    separate_center
        With polarization, include the center slots supplied by A. Must
        match A. With density alone, center handling remains in the model
        and this option has no effect on the original B construction.

    Notes
    -----
    Symmetrization acts only on the Cartesian-monomial dimension. Radial and
    density/type channels remain separate, so input and output shapes are

    ``A: [..., n_grid, n_radial_channels, n_monomials, n_channels]``

    ``B: [..., n_grid, n_radial_channels, n_B, n_channels]``.
    """

    def __init__(
        self, max_power: int, max_product_order: int = 3,
        *,
        include_polarization: bool = False, separate_center: bool = True,
    ) -> None:
        super().__init__()
        self.include_polarization = boolean(include_polarization, "include_polarization")
        self.separate_center = boolean(separate_center, "separate_center")

        max_product_order = positive_integer(
            max_product_order,
            "max_product_order",
        )
        if max_product_order > 3:
            raise ValueError("max_product_order must be between one and three")

        powers = _make_powers(max_power)
        component_indices, component_signs = _make_group_actions(
            powers, self.include_polarization, self.separate_center
        )
        recipes = _make_product_recipes(
            n_components=component_indices.shape[1],
            max_product_order=max_product_order,
            component_indices=component_indices,
            component_signs=component_signs,
        )

        self.max_power = int(max_power)
        self.max_product_order = max_product_order
        self.n_components = component_indices.shape[1]
        self.register_buffer("powers", powers)
        self.register_buffer("component_indices", component_indices)
        self.register_buffer("component_signs", component_signs)

        n_features_by_order = []
        correlation_orders = []
        for nu in range(1, max_product_order + 1):
            recipe = recipes[nu]
            self.register_buffer(
                "product_indices_{}".format(nu),
                recipe["product_indices"],
            )
            self.register_buffer(
                "coefficients_{}".format(nu),
                recipe["coefficients"],
            )
            self.register_buffer(
                "output_indices_{}".format(nu),
                recipe["output_indices"],
            )
            self.register_buffer(
                "representatives_{}".format(nu),
                recipe["representatives"],
            )

            n_features = recipe["representatives"].shape[0]
            n_features_by_order.append(n_features)
            correlation_orders.extend([nu] * n_features)

        self.n_features_by_order = tuple(n_features_by_order)
        self.n_features = sum(n_features_by_order)
        self.register_buffer(
            "correlation_orders",
            torch.tensor(correlation_orders, dtype=torch.long),
        )

    def validate_a_features(self, a_features) -> None:
        """Keep field membership and moment layout fixed at construction."""
        polarized = self.include_polarization
        if polarized != a_features.include_polarization:
            raise ValueError("A/B include_polarization must match")
        if a_features.max_power != self.max_power:
            raise ValueError("A/B max_power must match")
        if polarized and a_features.separate_center != self.separate_center:
            raise ValueError("A/B separate_center must match with polarization")

    def to_config(self) -> Dict[str, Any]:
        """Return the constructor arguments describing this module."""

        return make_config(
            self,
            max_power=self.max_power,
            max_product_order=self.max_product_order,
            include_polarization=self.include_polarization,
            separate_center=self.separate_center,
        )

    def forward(self, A: torch.Tensor) -> torch.Tensor:
        """Return signed-orbit averages through ``max_product_order``."""

        if A.ndim < 4:
            raise ValueError(
                "A must have shape "
                "[..., n_grid, n_radial_channels, n_monomials, n_channels]"
            )
        if A.shape[-2] != self.n_components:
            raise ValueError(
                "A monomial count does not match max_power={}".format(
                    self.max_power
                )
            )

        features_by_order = []
        for nu, n_features in enumerate(self.n_features_by_order, start=1):
            product_indices = getattr(self, "product_indices_{}".format(nu))
            coefficients = getattr(self, "coefficients_{}".format(nu))
            output_indices = getattr(self, "output_indices_{}".format(nu))

            # Explicit multiplication keeps higher derivatives reliable on
            # MPS. The term axis replaces the monomial axis.
            products = A.index_select(-2, product_indices[:, 0])
            for factor in range(1, nu):
                products = products * A.index_select(
                    -2,
                    product_indices[:, factor],
                )

            coefficient_shape = [1] * products.ndim
            coefficient_shape[-2] = coefficients.shape[0]
            weighted_products = products * coefficients.to(dtype=A.dtype).view(
                coefficient_shape
            )

            output_shape = list(A.shape)
            output_shape[-2] = n_features
            features_now = torch.zeros(
                output_shape,
                dtype=A.dtype,
                device=A.device,
            ).index_add(-2, output_indices, weighted_products)
            features_by_order.append(features_now)

        return torch.cat(features_by_order, dim=-2)
