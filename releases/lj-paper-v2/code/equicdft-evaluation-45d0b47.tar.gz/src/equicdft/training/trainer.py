"""Training orchestration for grid density-functional models."""

import math
from dataclasses import dataclass
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Type,
    Union,
)

import torch
from torch import nn

from .._validation import (
    boolean,
    nonempty_string,
    nonnegative_scalar,
    optional_positive_integer,
    positive_integer,
)
from .noise import NoiseOptions
from .._config import Configurable
from .checkpoint import (
    CHECKPOINT_VERSION,
    read_checkpoint,
    restore_history,
    restore_random_state,
)
from .io import append_log_message, format_record, write_history_csv
from .._device import GeometryDeviceCache, move_batch
from .._io import atomic_torch_save
from ..objectives import MetricCollection
from .loss import Loss

__all__ = [
    "TrainingStream",
    "Trainer",
]


@dataclass
class TrainingStream:
    """One data/loss/metric stream in a joint optimization.

    ``batches_per_step`` controls how many batches from this stream contribute
    to one optimizer update. Their losses are averaged before applying the
    stream weight. A stream with ``cycle=True`` is restarted when exhausted
    and follows the epoch length set by the non-cycling streams. Validation is
    always single-pass. ``model_kwargs`` makes response-only forwards such as
    ``compute_c1=False, compute_local_mu=False`` explicit without mutating
    persistent model flags.
    """

    name: str
    train_loader: Iterable[Dict[str, torch.Tensor]]
    valid_loader: Iterable[Dict[str, torch.Tensor]]
    loss: Loss
    metrics: Sequence[MetricCollection] = ()
    batches_per_step: int = 1
    model_kwargs: Optional[Dict[str, Any]] = None
    cycle: bool = False
    noise: Optional[NoiseOptions] = None

    def __post_init__(self) -> None:
        self.name = nonempty_string(self.name, "stream name")
        if not isinstance(self.loss, Loss):
            raise TypeError("stream loss must be a equicdft.Loss")
        self.metrics = tuple(self.metrics)
        for metric in self.metrics:
            if not isinstance(metric, MetricCollection):
                raise TypeError(
                    "stream metrics must be equicdft.MetricCollection objects"
                )
        metric_names = [metric.name for metric in self.metrics]
        if len(set(metric_names)) != len(metric_names):
            raise ValueError("metric collection names must be unique per stream")
        self.batches_per_step = positive_integer(
            self.batches_per_step,
            "batches_per_step",
        )
        self.model_kwargs = dict(self.model_kwargs or {})
        self.cycle = boolean(self.cycle, "cycle")
        if self.noise is None:
            self.noise = NoiseOptions()
        elif not isinstance(self.noise, NoiseOptions):
            raise TypeError("noise must be a NoiseOptions")


class Trainer:
    """Train a model with composable losses and dataset-level metrics.

    The trainer is a plain object that owns optimization and epoch
    orchestration while the model, loss, and metric modules retain their
    separate responsibilities; :meth:`to` moves all of them at once. The
    optimizer and scheduler are constructed on the first :meth:`fit`,
    :meth:`fit_streams` or :meth:`load_checkpoint` call from the parameters
    the model and loss modules already own.

    Models exposing ``voxel_weights(data)`` are evaluated with
    ``use_voxel_mask=True`` during training and validation. A TrainingStream
    may override this through ``model_kwargs``. SEM is applied before model
    evaluation, so density-cutoff weights follow the realized noisy density;
    independent support/exclusion masks remain unchanged.

    Parameters
    ----------
    model
        Model mapping a batched grid dictionary to an output dictionary.
    loss
        Aggregate :class:`equicdft.loss.Loss` module.
    metrics
        Metric collections updated for every train and validation batch.
    optimizer_cls
        PyTorch optimizer class.
    optimizer_args
        Keyword arguments passed to ``optimizer_cls``.
    scheduler_cls
        Optional PyTorch scheduler class. ``ReduceLROnPlateau`` receives the
        validation loss; other schedulers are stepped once after each epoch.
    scheduler_args
        Keyword arguments passed to ``scheduler_cls``.
    device
        Device used for the model and each tensor in a batch.
    checkpoint_dir
        Optional output directory. ``None`` disables checkpoint writing.
    checkpoint_interval
        Write ``checkpoint_epoch_XXXX.pt`` every this many epochs.
    save_best
        When checkpointing is enabled, update ``best.pt`` whenever validation
        loss improves. ``last.pt`` is updated after every epoch regardless.
    early_stopping_patience
        Optional number of consecutive epochs without validation-loss
        improvement allowed before stopping. ``None`` disables early
        stopping. The counter is preserved across checkpoint restarts.
    log_dir
        Optional directory for ``history.csv`` and ``training.log``.
        ``history.csv`` is atomically reconstructed from the complete trainer
        history after every epoch and after loading a checkpoint.
    noise
        :class:`NoiseOptions` applied before each training forward of
        :meth:`fit`; validation and explicit evaluation stay clean. Joint
        training uses the per-stream ``noise`` of :class:`TrainingStream`
        instead.
    """

    def __init__(
        self,
        model: nn.Module,
        loss: Loss,
        *,
        metrics: Sequence[MetricCollection] = (),
        optimizer_cls: Type[torch.optim.Optimizer] = torch.optim.Adam,
        optimizer_args: Optional[Dict[str, Any]] = None,
        scheduler_cls: Optional[Type[Any]] = None,
        scheduler_args: Optional[Dict[str, Any]] = None,
        device: Union[str, torch.device] = "cpu",
        checkpoint_dir: Optional[Union[str, Path]] = None,
        checkpoint_interval: int = 1,
        save_best: bool = True,
        early_stopping_patience: Optional[int] = None,
        log_dir: Optional[Union[str, Path]] = None,
        noise: Optional[NoiseOptions] = None,
    ) -> None:
        if not isinstance(model, nn.Module):
            raise TypeError("model must be a torch.nn.Module")
        if not isinstance(loss, Loss):
            raise TypeError("loss must be a equicdft.Loss")
        checkpoint_interval = positive_integer(
            checkpoint_interval,
            "checkpoint_interval",
        )
        save_best = boolean(save_best, "save_best")
        early_stopping_patience = optional_positive_integer(
            early_stopping_patience,
            "early_stopping_patience",
        )

        metrics = list(metrics)
        if any(not isinstance(metric, MetricCollection) for metric in metrics):
            raise TypeError(
                "metrics must contain only equicdft.MetricCollection objects"
            )
        metric_names = [metric.name for metric in metrics]
        if len(set(metric_names)) != len(metric_names):
            raise ValueError("metric collection names must be unique")

        self.model = model
        self.loss = loss
        self.metrics = tuple(metrics)
        self.optimizer_cls = optimizer_cls
        self.optimizer_args = dict(optimizer_args or {"lr": 1.0e-3})
        self.scheduler_cls = scheduler_cls
        self.scheduler_args = dict(scheduler_args or {})
        self.device = torch.device(device)
        self.checkpoint_interval = checkpoint_interval
        self.save_best = save_best
        self.early_stopping_patience = early_stopping_patience
        if noise is None:
            noise = NoiseOptions()
        elif not isinstance(noise, NoiseOptions):
            raise TypeError("noise must be a NoiseOptions")
        self.noise = noise

        self.checkpoint_dir = None
        if checkpoint_dir is not None:
            self.checkpoint_dir = Path(checkpoint_dir).expanduser()
            self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.log_dir = None
        self.history_path = None
        self.training_log_path = None
        if log_dir is not None:
            self.log_dir = Path(log_dir).expanduser()
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self.history_path = self.log_dir / "history.csv"
            self.training_log_path = self.log_dir / "training.log"

        self.optimizer = None
        self.scheduler = None
        self.history = []
        self.best_valid_loss = math.inf
        self.epochs_without_improvement = 0
        self._train_loader_generator = None
        self.stream_losses = nn.ModuleDict()
        self.stream_metrics: Dict[str, Tuple[MetricCollection, ...]] = {}
        self._streams = ()
        self._stream_loader_generators = {}
        self._grid_geometry_device_cache = GeometryDeviceCache()
        self._move_to_device()

    def to(self, device: Union[str, torch.device]) -> "Trainer":
        """Move modules and any optimizer state, preserving training progress."""

        previous_parameters = self._optimization_parameters()
        optimizer_state = (
            None if self.optimizer is None else self.optimizer.state_dict()
        )
        self.device = torch.device(device)
        self._move_to_device()
        if self.optimizer is not None:
            # Module.to may replace Parameter objects. Keep optimizer groups
            # attached to the live parameters and let its loader apply the
            # optimizer's device policy (e.g. Adam's CPU step counter).
            replacements = dict(zip(previous_parameters, self._optimization_parameters()))
            for group in self.optimizer.param_groups:
                group["params"] = [replacements[p] for p in group["params"]]
            self.optimizer.load_state_dict(optimizer_state)
        self._grid_geometry_device_cache.clear()
        return self

    def _move_to_device(self) -> None:
        self.model.to(self.device)
        self.loss.to(self.device)
        for metric in self.metrics:
            metric.to(self.device)
        self.stream_losses.to(self.device)
        for metrics in self.stream_metrics.values():
            for metric in metrics:
                metric.to(self.device)

    def fit(
        self,
        train_loader: Iterable[Dict[str, torch.Tensor]],
        valid_loader: Iterable[Dict[str, torch.Tensor]],
        epochs: int,
        verbose: bool = True,
        print_interval: int = 1,
        record_initial_validation: bool = False,
    ) -> List[Dict[str, Any]]:
        """Run complete train/validation epochs and return their history.

        ``fit`` is the single-stream form of :meth:`fit_streams`: it wraps
        the loaders, the trainer's loss, metrics and noise settings in one
        ``TrainingStream`` named ``"default"`` and records history and
        checkpoints in the flat (unprefixed) layout. With
        ``record_initial_validation`` the untrained validation result is
        first recorded as epoch 0, as in :meth:`fit_streams`.
        """

        epochs = positive_integer(epochs, "epochs")
        verbose = boolean(verbose, "verbose")
        print_interval = positive_integer(print_interval, "print_interval")
        record_initial_validation = boolean(
            record_initial_validation, "record_initial_validation",
        )

        self._train_loader_generator = getattr(train_loader, "generator", None)
        self._initialize_optimization()
        start_epoch = self._next_epoch()
        stream = TrainingStream(
            "default",
            train_loader,
            valid_loader,
            self.loss,
            metrics=tuple(self.metrics),
            noise=self.noise,
        )
        if record_initial_validation and not self.history:
            self._record_baseline(stream, verbose)
            start_epoch = self._next_epoch()

        if self._stop_before_training(verbose):
            return self.history

        for epoch in range(start_epoch, start_epoch + epochs):
            train_losses, train_metrics = self._run_training_streams(
                (stream,),
                {stream.name: 1.0},
            )[stream.name]
            valid_losses, valid_metrics = self._evaluate_stream(
                stream,
                subset="valid",
            )

            learning_rate = self.optimizer.param_groups[0]["lr"]
            record = {
                "epoch": epoch,
                "learning_rate": learning_rate,
                "train_losses": train_losses,
                "valid_losses": valid_losses,
                "train_metrics": train_metrics,
                "valid_metrics": valid_metrics,
            }
            if self._finish_epoch(record, verbose, print_interval):
                break

        return self.history

    def fit_streams(
        self,
        streams: Sequence[TrainingStream],
        epochs: int,
        stream_weights: Optional[
            Mapping[str, Union[float, Callable[[int], float]]]
        ] = None,
        verbose: bool = True,
        print_interval: int = 1,
        record_initial_validation: bool = False,
    ) -> List[Dict[str, Any]]:
        """Jointly optimize multiple data streams without mixing datasets.

        Non-cycling streams are consumed exactly once per epoch. At each
        optimizer update, up to ``batches_per_step`` batches are drawn from
        every still-active non-cycling stream and every cycling stream. Cycling
        streams restart as needed until the non-cycling streams are exhausted.
        Losses are averaged within each stream. Stream weights may be constants
        or callables of the one-based epoch number. Validation is evaluated
        exactly once for every stream; the weighted sum of validation totals
        drives the configured scheduler and ordinary ``best.pt``.
        If requested, the untrained validation result is first recorded as
        epoch 0, using stream-weight callables evaluated at zero.
        """

        epochs = positive_integer(epochs, "epochs")
        record_initial_validation = boolean(
            record_initial_validation,
            "record_initial_validation",
        )
        verbose = boolean(verbose, "verbose")
        print_interval = positive_integer(print_interval, "print_interval")
        streams = self._configure_streams(streams)
        weight_specification = dict(stream_weights or {})
        unknown_weights = set(weight_specification) - {
            stream.name for stream in streams
        }
        if unknown_weights:
            raise KeyError(
                "stream_weights contains unknown streams: {}".format(
                    sorted(unknown_weights)
                )
            )

        self._initialize_optimization()
        if record_initial_validation and not self.history:
            self._record_stream_baseline(
                streams,
                self._resolve_stream_weights(
                    streams,
                    weight_specification,
                    epoch=0,
                ),
                verbose,
            )
        start_epoch = self._next_epoch()
        if self._stop_before_training(verbose):
            return self.history

        for epoch in range(start_epoch, start_epoch + epochs):
            weights = self._resolve_stream_weights(
                streams,
                weight_specification,
                epoch,
            )
            train_by_stream = self._run_training_streams(streams, weights)
            valid_by_stream = {
                stream.name: self._evaluate_stream(
                    stream,
                    subset="valid",
                )
                for stream in streams
            }
            train_losses, train_metrics = self._flatten_stream_results(
                train_by_stream,
                weights,
            )
            valid_losses, valid_metrics = self._flatten_stream_results(
                valid_by_stream,
                weights,
            )
            record = {
                "epoch": epoch,
                "learning_rate": self.optimizer.param_groups[0]["lr"],
                "stream_weights": weights,
                "train_losses": train_losses,
                "valid_losses": valid_losses,
                "train_metrics": train_metrics,
                "valid_metrics": valid_metrics,
            }
            if self._finish_epoch(record, verbose, print_interval):
                break
        return self.history

    def evaluate_streams(
        self,
        streams: Sequence[TrainingStream],
        subset: str = "valid",
    ) -> Dict[str, Tuple[Dict[str, float], Dict[str, Dict[str, float]]]]:
        """Evaluate named streams independently without optimizer updates."""

        if subset not in ("train", "valid"):
            raise ValueError("subset must be 'train' or 'valid'")
        streams = self._validate_streams(streams)
        return {
            stream.name: self._evaluate_stream(
                stream,
                subset=subset,
            )
            for stream in streams
        }

    def _record_baseline(self, stream: TrainingStream, verbose: bool) -> None:
        """Append the validation-only epoch 0 of :meth:`fit`."""

        valid_losses, valid_metrics = self._evaluate_stream(stream, subset="valid")
        self._append_baseline(
            {
                "epoch": 0,
                "learning_rate": self.optimizer.param_groups[0]["lr"],
                "train_losses": {},
                "valid_losses": valid_losses,
                "train_metrics": {},
                "valid_metrics": valid_metrics,
            },
            verbose,
        )

    def _record_stream_baseline(
        self,
        streams: Sequence[TrainingStream],
        weights: Mapping[str, float],
        verbose: bool,
    ) -> None:
        """Append the validation-only epoch 0 of :meth:`fit_streams`."""

        evaluated = {
            stream.name: self._evaluate_stream(
                stream,
                subset="valid",
            )
            for stream in streams
        }
        valid_losses, valid_metrics = self._flatten_stream_results(
            evaluated,
            weights,
        )
        self._append_baseline(
            {
                "epoch": 0,
                "learning_rate": self.optimizer.param_groups[0]["lr"],
                "stream_weights": weights,
                "train_losses": {},
                "valid_losses": valid_losses,
                "train_metrics": {},
                "valid_metrics": valid_metrics,
            },
            verbose,
        )

    def _append_baseline(self, record: Dict[str, Any], verbose: bool) -> None:
        self.history.append(record)
        self._write_history_csv()
        if verbose:
            self.log_message(
                "Untrained validation baseline\n" + format_record(record)
            )

    def save_checkpoint(
        self,
        path: Union[str, Path],
        record: Dict[str, Any],
    ) -> None:
        """Write model, optimization, scheduler, and history state.

        Only current-format training checkpoints can be resumed.
        """

        checkpoint = {
            "checkpoint_version": CHECKPOINT_VERSION,
            "epoch": record["epoch"],
            "model_config": (
                self.model.to_config()
                if isinstance(self.model, Configurable)
                else None
            ),
            "model_state_dict": self.model.state_dict(),
            "loss_state_dict": self.loss.state_dict(),
            "stream_loss_state_dict": (
                self.stream_losses.state_dict() if self._streams else None
            ),
            "stream_names": [stream.name for stream in self._streams],
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": (
                None if self.scheduler is None else self.scheduler.state_dict()
            ),
            "record": record,
            "history": self.history,
            "best_valid_loss": self.best_valid_loss,
            "epochs_without_improvement": self.epochs_without_improvement,
            "noise": self.noise.to_dict(),
            "stream_noise": {
                stream.name: stream.noise.to_dict() for stream in self._streams
            },
            "torch_rng_state": torch.get_rng_state(),
            "cuda_rng_state_all": (
                torch.cuda.get_rng_state_all()
                if torch.cuda.is_available()
                else None
            ),
            "train_loader_generator_state": (
                self._train_loader_generator.get_state()
                if self._train_loader_generator is not None
                else None
            ),
            "stream_loader_generator_states": {
                name: (
                    generator.get_state() if generator is not None else None
                )
                for name, generator in self._stream_loader_generators.items()
            },
        }
        atomic_torch_save(checkpoint, Path(path).expanduser())

    def load_checkpoint(
        self,
        path: Union[str, Path],
        train_loader: Iterable[Dict[str, torch.Tensor]],
    ) -> int:
        """Restore a complete training state and return its completed epoch.

        ``train_loader`` is the loader the resumed run will iterate; its
        random generator state is restored from the checkpoint. Random states
        are restored last, undoing any draws made while constructing the
        replacement process.
        """

        checkpoint = read_checkpoint(path, self.device)
        self._train_loader_generator = getattr(train_loader, "generator", None)
        self._initialize_optimization()

        self.model.load_state_dict(checkpoint["model_state_dict"], strict=True)
        self.noise = NoiseOptions.from_dict(checkpoint["noise"])
        stream_noise = {
            name: NoiseOptions.from_dict(values)
            for name, values in checkpoint["stream_noise"].items()
        }
        for stream in self._streams:
            stream.noise = stream_noise.get(stream.name, NoiseOptions())
        self.loss.load_state_dict(checkpoint["loss_state_dict"], strict=True)
        stream_loss_state = checkpoint.get("stream_loss_state_dict")
        if stream_loss_state is not None:
            expected_names = checkpoint.get("stream_names", [])
            actual_names = [stream.name for stream in self._streams]
            if expected_names != actual_names:
                raise ValueError(
                    "checkpoint stream names do not match configured streams"
                )
            self.stream_losses.load_state_dict(stream_loss_state, strict=True)
        elif self._streams:
            raise ValueError(
                "checkpoint has no stream-loss state for configured streams"
            )
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

        scheduler_state = checkpoint["scheduler_state_dict"]
        if self.scheduler is None and scheduler_state is not None:
            raise ValueError(
                "checkpoint contains scheduler state but no scheduler is configured"
            )
        if self.scheduler is not None and scheduler_state is None:
            raise ValueError(
                "checkpoint has no scheduler state but a scheduler is configured"
            )
        if self.scheduler is not None:
            self.scheduler.load_state_dict(scheduler_state)

        (
            epoch,
            self.history,
            self.best_valid_loss,
            self.epochs_without_improvement,
        ) = restore_history(checkpoint)

        restore_random_state(
            checkpoint,
            self._train_loader_generator,
            self._stream_loader_generators,
        )

        for metric in self.metrics:
            for subset in metric.subsets:
                metric.clear_metrics(subset)
        for metrics in self.stream_metrics.values():
            for metric in metrics:
                for subset in metric.subsets:
                    metric.clear_metrics(subset)
        self._write_history_csv()
        return epoch

    def load_stream_checkpoint(
        self,
        path: Union[str, Path],
        streams: Sequence[TrainingStream],
    ) -> int:
        """Restore a joint-stream checkpoint using the same stream layout."""

        streams = self._configure_streams(streams)
        return self.load_checkpoint(path, train_loader=streams[0].train_loader)

    def log_message(self, message: str, display: bool = True) -> None:
        """Print a message and append it to the human-readable training log."""

        append_log_message(message, self.training_log_path, display)

    def _initialize_optimization(self) -> None:
        """Construct the optimizer and scheduler once."""

        if self.optimizer is not None:
            return

        self.optimizer = self.optimizer_cls(
            self._optimization_parameters(),
            **self.optimizer_args,
        )
        if self.scheduler_cls is not None:
            self.scheduler = self.scheduler_cls(
                self.optimizer,
                **self.scheduler_args,
            )

    def _optimization_parameters(self) -> List[nn.Parameter]:
        """Model and loss parameters in stable order, without shared duplicates."""

        parameters = list(self.model.parameters()) + list(self.loss.parameters())
        parameters.extend(self.stream_losses.parameters())
        return list(dict.fromkeys(parameters))

    @staticmethod
    def _validate_streams(
        streams: Sequence[TrainingStream],
        require_epoch_driver: bool = False,
    ) -> Tuple[TrainingStream, ...]:
        """Return a validated stream tuple without changing trainer state."""

        streams = tuple(streams)
        if not streams:
            raise ValueError("streams must contain at least one stream")
        if any(not isinstance(stream, TrainingStream) for stream in streams):
            raise TypeError("streams must contain only TrainingStream objects")
        names = [stream.name for stream in streams]
        if len(set(names)) != len(names):
            raise ValueError("stream names must be unique")
        if require_epoch_driver and all(stream.cycle for stream in streams):
            raise ValueError(
                "at least one training stream must have cycle=False"
            )
        return streams

    def _configure_streams(
        self,
        streams: Sequence[TrainingStream],
    ) -> Tuple[TrainingStream, ...]:
        """Validate and register a stable set of training streams."""

        streams = self._validate_streams(
            streams,
            require_epoch_driver=True,
        )
        if not self._streams and self.optimizer is not None:
            raise ValueError(
                "cannot configure streams after optimization has started"
            )
        if self._streams and (
            len(streams) != len(self._streams)
            or any(
                supplied is not configured
                for supplied, configured in zip(streams, self._streams)
            )
        ):
            raise ValueError("configured streams cannot change once registered")
        if not self._streams:
            self.stream_losses = nn.ModuleDict(
                {stream.name: stream.loss for stream in streams}
            )
            self.stream_metrics = {
                stream.name: tuple(stream.metrics) for stream in streams
            }
            self._streams = streams
            self._stream_loader_generators = {
                stream.name: getattr(stream.train_loader, "generator", None)
                for stream in streams
            }
            self._move_to_device()
        return self._streams

    @staticmethod
    def _stream_weight(
        specification: Union[float, Callable[[int], float]],
        epoch: int,
        name: str,
    ) -> float:
        value = specification(epoch) if callable(specification) else specification
        return nonnegative_scalar(value, "{} stream weight".format(name))

    def _resolve_stream_weights(
        self,
        streams: Sequence[TrainingStream],
        specifications: Mapping[
            str,
            Union[float, Callable[[int], float]],
        ],
        epoch: int,
    ) -> Dict[str, float]:
        """Evaluate all stream-weight specifications for one epoch."""

        return {
            stream.name: self._stream_weight(
                specifications.get(stream.name, 1.0),
                epoch,
                stream.name,
            )
            for stream in streams
        }

    def _run_training_streams(
        self,
        streams: Sequence[TrainingStream],
        weights: Mapping[str, float],
    ) -> Dict[str, Tuple[Dict[str, float], Dict[str, Dict[str, float]]]]:
        """Run joint updates, cycling opted-in streams to the epoch length."""

        if not any(weight > 0.0 for weight in weights.values()):
            raise ValueError("at least one training stream must have positive weight")
        self.model.train(True)
        for stream in streams:
            stream.loss.train(True)
        iterators = {stream.name: iter(stream.train_loader) for stream in streams}
        active = {stream.name for stream in streams if not stream.cycle}
        loss_sums = {stream.name: {} for stream in streams}
        field_counts = {stream.name: 0 for stream in streams}

        while active:
            groups = {}
            # Non-cycling streams define the epoch length. Gather them first so
            # cycling streams never create an extra update after the last
            # ordinary stream is exhausted.
            for stream in streams:
                if stream.cycle or stream.name not in active:
                    continue
                batches = []
                for _ in range(stream.batches_per_step):
                    try:
                        batches.append(next(iterators[stream.name]))
                    except StopIteration:
                        active.remove(stream.name)
                        break
                if batches:
                    groups[stream.name] = batches
            if not groups:
                break

            for stream in streams:
                if not stream.cycle:
                    continue
                batches = []
                for _ in range(stream.batches_per_step):
                    try:
                        batch = next(iterators[stream.name])
                    except StopIteration:
                        iterators[stream.name] = iter(stream.train_loader)
                        try:
                            batch = next(iterators[stream.name])
                        except StopIteration as error:
                            raise ValueError(
                                "cycling train loader for stream '{}' is empty".format(
                                    stream.name
                                )
                            ) from error
                    batches.append(batch)
                groups[stream.name] = batches

            self.optimizer.zero_grad(set_to_none=True)
            for stream in streams:
                batches = groups.get(stream.name, ())
                for batch in batches:
                    batch, outputs, losses, details = self._forward_loss(
                        batch,
                        stream.loss,
                        stream.model_kwargs,
                        noise=stream.noise,
                    )
                    self._update_metrics(
                        stream.metrics,
                        "train",
                        outputs,
                        batch,
                        details,
                    )
                    (
                        weights[stream.name]
                        * losses["total"]
                        / len(batches)
                    ).backward()
                    n_fields = int(batch["rho"].shape[0])
                    for loss_name, value in losses.items():
                        loss_sums[stream.name][loss_name] = (
                            loss_sums[stream.name].get(loss_name, 0.0)
                            + value.detach().item() * n_fields
                        )
                    field_counts[stream.name] += n_fields
            self.optimizer.step()

        results = {}
        for stream in streams:
            n_fields = field_counts[stream.name]
            if n_fields == 0:
                raise ValueError(
                    "train_loader for stream '{}' is empty".format(stream.name)
                )
            losses = {
                name: value / n_fields
                for name, value in loss_sums[stream.name].items()
            }
            metrics = self._retrieve_metrics(stream.metrics, "train")
            results[stream.name] = (losses, metrics)
        return results

    def _evaluate_stream(
        self,
        stream: TrainingStream,
        subset: str,
    ) -> Tuple[Dict[str, float], Dict[str, Dict[str, float]]]:
        """Evaluate one named stream without combining its statistics."""

        if subset == "train":
            loader = stream.train_loader
        elif subset == "valid":
            loader = stream.valid_loader
        else:
            raise ValueError("subset must be 'train' or 'valid'")

        self.model.eval()
        stream.loss.to(self.device).eval()
        for metric in stream.metrics:
            metric.to(self.device)
        loss_sums = {}
        n_fields = 0
        with torch.no_grad():
            for batch in loader:
                batch, outputs, losses, details = self._forward_loss(
                    batch,
                    stream.loss,
                    stream.model_kwargs,
                )
                self._update_metrics(
                    stream.metrics,
                    subset,
                    outputs,
                    batch,
                    details,
                )
                n_batch_fields = int(batch["rho"].shape[0])
                for name, value in losses.items():
                    loss_sums[name] = loss_sums.get(name, 0.0) + (
                        value.detach().item() * n_batch_fields
                    )
                n_fields += n_batch_fields
        if n_fields == 0:
            raise ValueError(
                "{} loader for stream '{}' is empty".format(subset, stream.name)
            )
        losses = {name: value / n_fields for name, value in loss_sums.items()}
        return losses, self._retrieve_metrics(stream.metrics, subset)

    @staticmethod
    def _update_metrics(
        metrics: Sequence[MetricCollection],
        subset: str,
        outputs: Dict[str, torch.Tensor],
        batch: Dict[str, torch.Tensor],
        details: Dict[str, Dict[str, torch.Tensor]],
    ) -> None:
        for metric in metrics:
            metric.update_metrics(subset, outputs, batch, details)

    @staticmethod
    def _retrieve_metrics(
        metrics: Sequence[MetricCollection],
        subset: str,
    ) -> Dict[str, Dict[str, float]]:
        return {
            metric.name: {
                name: value.item()
                for name, value in metric.retrieve_metrics(subset).items()
            }
            for metric in metrics
        }

    def _forward_loss(
        self,
        batch: Dict[str, torch.Tensor],
        loss: Loss,
        model_kwargs: Optional[Dict[str, Any]] = None,
        noise: Optional[NoiseOptions] = None,
    ) -> Tuple[
        Dict[str, torch.Tensor],
        Dict[str, torch.Tensor],
        Dict[str, torch.Tensor],
        Dict[str, Dict[str, torch.Tensor]],
    ]:
        """Move one batch, run the model, and evaluate one loss module."""

        batch = self._move_batch(batch)
        model_kwargs = dict(model_kwargs or {})
        selection = getattr(self.model, "voxel_weights", None)
        if selection is not None:
            model_kwargs.setdefault("use_voxel_mask", True)
        if noise is not None:
            batch = noise.apply(batch, ideal=getattr(self.model, "ideal", None))
        outputs = self.model(batch, **model_kwargs)
        losses, details = loss.evaluate(outputs, batch, model=self.model)
        return batch, outputs, losses, details

    @staticmethod
    def _flatten_stream_results(
        results: Mapping[
            str,
            Tuple[Dict[str, float], Dict[str, Dict[str, float]]],
        ],
        weights: Mapping[str, float],
    ) -> Tuple[Dict[str, float], Dict[str, Dict[str, float]]]:
        losses = {}
        metrics = {}
        total = 0.0
        for stream_name, (stream_losses, stream_metrics) in results.items():
            total += weights[stream_name] * stream_losses["total"]
            for name, value in stream_losses.items():
                losses["{}/{}".format(stream_name, name)] = value
            for name, values in stream_metrics.items():
                metrics["{}/{}".format(stream_name, name)] = values
        losses["total"] = total
        return losses, metrics

    def _step_scheduler(self, valid_loss: float) -> None:
        """Advance an optional scheduler using its expected calling style."""

        if self.scheduler is None:
            return
        if isinstance(
            self.scheduler,
            torch.optim.lr_scheduler.ReduceLROnPlateau,
        ):
            self.scheduler.step(valid_loss)
        else:
            self.scheduler.step()

    def _finish_epoch(
        self,
        record: Dict[str, Any],
        verbose: bool,
        print_interval: int,
    ) -> bool:
        """Record one epoch and return whether early stopping was reached."""

        self.history.append(record)
        self._step_scheduler(record["valid_losses"]["total"])
        self._write_epoch_checkpoints(record)
        self._write_history_csv()
        if verbose and record["epoch"] % print_interval == 0:
            self.log_message(format_record(record))
        if not self._early_stopping_reached():
            return False
        self.log_message(
            "Early stopping at epoch {} after {} epochs without "
            "validation-loss improvement.".format(
                record["epoch"],
                self.epochs_without_improvement,
            ),
            display=verbose,
        )
        return True

    def _stop_before_training(self, verbose: bool) -> bool:
        """Report an already exhausted patience counter before another fit."""

        if not self._early_stopping_reached():
            return False
        self.log_message(
            "Early stopping already reached after {} epochs without "
            "validation-loss improvement.".format(
                self.epochs_without_improvement
            ),
            display=verbose,
        )
        return True

    def _write_epoch_checkpoints(self, record: Dict[str, Any]) -> None:
        """Write configured periodic, best, and last checkpoints."""

        epoch = record["epoch"]
        valid_loss = record["valid_losses"]["total"]
        improved = valid_loss < self.best_valid_loss
        if improved:
            self.best_valid_loss = valid_loss
            self.epochs_without_improvement = 0
        else:
            self.epochs_without_improvement += 1
        if self.checkpoint_dir is None:
            return

        is_best = self.save_best and improved
        if epoch % self.checkpoint_interval == 0:
            self.save_checkpoint(
                self.checkpoint_dir
                / "checkpoint_epoch_{:04d}.pt".format(epoch),
                record,
            )
        if is_best:
            self.save_checkpoint(self.checkpoint_dir / "best.pt", record)
        self.save_checkpoint(self.checkpoint_dir / "last.pt", record)

    def _early_stopping_reached(self) -> bool:
        """Return whether the configured validation patience is exhausted."""

        return (
            self.early_stopping_patience is not None
            and self.epochs_without_improvement
            >= self.early_stopping_patience
        )

    def _write_history_csv(self) -> None:
        """Atomically write one flattened numerical row per completed epoch."""

        if self.history_path is None or not self.history:
            return

        write_history_csv(self.history, self.history_path)

    def _move_batch(
        self,
        batch: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        """Move batch tensors while reusing identity-shared grid geometry."""

        return move_batch(batch, self.device, self._grid_geometry_device_cache)

    def _next_epoch(self) -> int:
        """Return the next positive training epoch after optional epoch 0."""

        return self.history[-1]["epoch"] + 1 if self.history else 1
