"""Public construction interface for complete periodic density fields."""

from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Union

import numpy as np
from ase import Atoms
from ase.io import read
from torch.utils.data import Dataset

from .._validation import boolean, nonnegative_integer, positive_scalar
from .extxyz import (
    _metadata_positive_integer,
    _metadata_positive_scalar,
    build_grid_data,
    harmonize_optional_fields,
    normalize_grid_info,
    process_atoms,
    validate_frame_grid_info,
)
from .metal import normalize_metal_sites
from ..geometry.stencil import grid_size_array, grid_spacing_array

__all__ = [
    "DEFAULT_BOLTZMANN_CONSTANT",
    "GridDataset",
    "default_data_key",
    "read_metal_sites",
    "GridData",
]


# Temperatures in kelvin and energies in electronvolts unless a dataset says
# otherwise; reduced-unit datasets pass boltzmann_constant=1.0. The model
# shares this default (see equicdft.units).
from ..units import DEFAULT_BOLTZMANN_CONSTANT  # noqa: E402


# Canonical GridData field -> source field in the EXTXYZ/ASE Atoms object.
# Callers can override any subset of source names through `data_key`.
default_data_key = {
    "temperature": "T",
    "mu": "mu",
    "grid_spacing": "grid_spacing",
    "grid_size": "grid_size",
    "grid_indexing": "grid_indexing",
    "grid_positions": "positions",
    "grid_center": "grid_center",
    "V_ext": "V_ext",
    "rho": "density",
    "rho_std": "density_std",
    "dipole_density": "dipole_density",
    "dipole_density_std": "dipole_density_std",
    "excluded_mask": "excluded_mask",
    "mask": "mask",
}


def read_metal_sites(
    path: Union[str, Path], *, origin=(0.0, 0.0, 0.0), site_groups=None,
    total_charge=None, index=0,
) -> Dict[str, Any]:
    """Read one XYZ/ASE metal geometry and its charge constraints.

    XYZ positions use the same physical frame and length units as grid_center.
    By default coordinates are unchanged. Optional ``origin`` explicitly
    translates the file by returning ``positions - origin``; use it only to
    align a differently referenced file, not to subtract the liquid grid origin.
    No wrapping, rescaling, density mask, or field origin is inferred.

    Site labels come from ``site_groups`` or the ASE array
    ``metal_site_groups``. A scalar total charge defines one group; a mapping
    such as ``{0: 1.0, 1: -1.0}`` assigns total charge by site label. If no
    labels are present, the scalar case places every site in group 0. Charges
    are expressed in elementary-charge units.
    """
    atoms = read(str(Path(path).expanduser()), index=index)
    if not isinstance(atoms, Atoms):
        raise ValueError("read_metal_sites requires one selected XYZ frame")
    offset = np.asarray(origin)
    if (offset.shape != (3,) or not np.issubdtype(offset.dtype, np.number)
            or np.issubdtype(offset.dtype, np.complexfloating)
            or not np.all(np.isfinite(offset))):
        raise ValueError("origin must contain three real finite coordinates")
    positions = atoms.get_positions() - offset.astype(np.float64)
    labels = (
        atoms.arrays.get("metal_site_groups")
        if site_groups is None else site_groups
    )
    if total_charge is None:
        raise ValueError("total_charge must be supplied")
    if isinstance(total_charge, Mapping):
        ids = list(total_charge)
        totals = list(total_charge.values())
    else:
        totals = total_charge
        ids = None
    if labels is None:
        raw_totals = None if totals is None else np.asarray(totals).reshape(-1)
        if ids is None and raw_totals is not None and raw_totals.size == 1:
            ids = [0]
        raw_ids = None if ids is None else np.asarray(ids).reshape(-1)
        if raw_ids is None or raw_ids.size != 1:
            raise ValueError(
                "site_groups are required for multiple electrode groups"
            )
        ids = raw_ids
        labels = np.full(len(atoms), raw_ids[0])
    else:
        if np.ndim(labels) == 0:
            labels = np.full(len(atoms), labels)
        if ids is None:
            unique_labels = np.unique(np.asarray(labels))
            raw_totals = None if totals is None else np.asarray(totals).reshape(-1)
            if unique_labels.size != 1 or raw_totals is None or raw_totals.size != 1:
                raise ValueError(
                    "multiple electrode groups require total_charge as a "
                    "{label: charge} mapping"
                )
            ids = unique_labels
    return normalize_metal_sites(
        ids, totals, "e",
        metal_positions=positions, metal_site_groups=labels,
    )


def _normalize_xyz_paths(
    path: Union[str, Path, Sequence[Union[str, Path]]],
) -> List[Path]:
    """Return a validated nonempty list of expanded EXTXYZ paths."""

    if isinstance(path, (str, Path)):
        return [Path(path).expanduser()]
    if not isinstance(path, Sequence):
        raise TypeError(
            "path must be a path-like value or a sequence of path-like values"
        )
    values = list(path)
    if not values:
        raise ValueError("path sequence must not be empty")
    if any(not isinstance(value, (str, Path)) for value in values):
        raise TypeError(
            "every item in path must be a string or pathlib.Path"
        )
    return [Path(value).expanduser() for value in values]


class GridDataset(list, Dataset):
    """A list of :class:`GridData` fields that is also a torch ``Dataset``.

    :meth:`GridData.from_xyz` returns one. Every list operation (indexing,
    slicing, ``len``, iteration, concatenation) keeps working, and the
    object can be handed to ``torch.utils.data.DataLoader`` or
    :func:`equicdft.make_dataloaders` like :class:`FourierResponseData`.
    Slices are plain lists; wrap them again when a ``Dataset`` is needed.
    """


class GridData(dict):
    """Dictionary-like data for one complete periodic density configuration.

    Every object contains the grid geometry, temperature, beta, and stencil
    offsets. Density, external-potential, chemical-potential, reference, and
    explicit-neighborhood fields are included only when requested and
    available::

        temperature                 scalar
        beta                        scalar, 1 / (k_B*T)
        mu                          [n_types] (optional, energy units)
        beta_mu                     [n_types] (optional, dimensionless beta*mu)
        n_types                     scalar
        thermal_wavelength          [n_types] (when needed for inference)
        grid_spacing                [3]
        index                       [n_grid]
        grid_positions              [n_grid, 3]
        grid_center                 [n_grid, 3], physical coordinates (optional)
        V_ext                       [n_grid, n_types] (optional)
        rho                         [n_grid, n_types] (optional)
        rho_std                     [n_grid, n_types] (optional, density units)
        dipole_density              [n_grid, n_types, 3] (optional, polar vector)
        dipole_density_std          [n_grid, n_types, 3] (optional, P units)
        excluded_mask               [n_grid] bool; true grid points are excluded
        mask                        [n_grid] bool; true voxels are frozen in evolution
        local_density_index         [n_grid, n_neighbors] (optional)
        local_density_positions     [n_neighbors, 3]

    EXTXYZ records require at least one of ``rho`` and ``V_ext``. A grid built
    directly with :meth:`from_dict` may initially contain neither. Model
    gather backends use ``local_density_index`` to read from the live ``rho``
    tensor, preserving the functional-derivative graph. FFT/conv3d local
    operators do not use this potentially large table, so callers may omit it
    explicitly with ``include_local_density_index=False``.
    Optional grid_center gives fixed physical voxel centers in float64. It
    must describe a translated regular grid with the declared grid_spacing.
    Without it, physical centers are grid_positions * grid_spacing (no offset).

    ``dipole_density`` is dipole moment per physical volume, not dipole per
    particle. Its Cartesian components are signed and use one shared unit.
    EXTXYZ stores each type's x/y/z consecutively in ``3*n_types`` columns;
    coarsening averages components, preserving the integrated dipole vector.
    Polarized frames do not receive automatic scalar-fluid ``c1`` targets:
    their ideal orientational free energy must first be specified. Temperature,
    beta, and any supplied chemical-potential metadata are still retained.
    """

    @classmethod
    def from_xyz(
        cls,
        path: Union[str, Path, Sequence[Union[str, Path]]],
        cutoff_grid: int = 3,
        index: str = ":",
        data_key: Optional[Dict[str, str]] = None,
        target_grid_spacing: Optional[
            Union[float, Sequence[float], np.ndarray]
        ] = None,
        boltzmann_constant: float = DEFAULT_BOLTZMANN_CONSTANT,
        thermal_wavelength: Union[
            float, Sequence[float], np.ndarray
        ] = 1.0,
        grid_info: Optional[Mapping[str, Any]] = None,
        include_local_density_index: bool = True,
    ) -> "GridDataset":
        """Read selected EXTXYZ frames into complete periodic grid records.

        Returns a :class:`GridDataset`, a list of :class:`GridData` records
        that is also a torch ``Dataset``. ``path`` may contain one path or an
        ordered sequence. ``data_key``
        maps canonical field names to EXTXYZ names. If
        ``target_grid_spacing`` is supplied, available fields are block-
        averaged before neighborhoods are constructed. ``grid_info`` may be
        supplied from a trained model to configure and validate its grid and
        unit metadata. Set ``include_local_density_index=False`` only when the
        consuming model reports ``requires_local_density_index=False``.
        Optional ``rho_std`` and ``dipole_density_std`` specify componentwise
        Gaussian noise sigma in their corresponding field units, without
        statistical rescaling. To use uncertainty of the mean, map them to
        SEM properties, e.g. ``data_key={"rho_std": "density_sem",
        "dipole_density_std": "dipole_density_sem"}``. Supply uncertainties
        on the final grid; coarsening requires covariance information.
        """

        resolved_grid_info = None
        if grid_info is not None:
            resolved_grid_info = normalize_grid_info(grid_info)
            cutoff_grid = resolved_grid_info["cutoff_grid"]
            boltzmann_constant = resolved_grid_info["boltzmann_constant"]
            thermal_wavelength = resolved_grid_info["thermal_wavelength"]
        cutoff_grid = nonnegative_integer(cutoff_grid, "cutoff_grid")
        boltzmann_constant = positive_scalar(
            boltzmann_constant,
            "boltzmann_constant",
        )
        include_local_density_index = boolean(
            include_local_density_index,
            "include_local_density_index",
        )

        keys = default_data_key.copy()
        if data_key is not None:
            unknown_keys = set(data_key) - set(default_data_key)
            if unknown_keys:
                raise KeyError(
                    "unknown GridData data_key entries: {}".format(
                        sorted(unknown_keys)
                    )
                )
            keys.update(data_key)

        configurations: List[Atoms] = []
        for xyz_path in _normalize_xyz_paths(path):
            selected = read(str(xyz_path), index=index)
            if isinstance(selected, list):
                configurations.extend(selected)
            else:
                configurations.append(selected)

        # Complete fields normally share their immutable neighborhood tensors.
        geometry_cache: Dict[Any, Any] = {}
        data = [
            cls(
                **process_atoms(
                    atoms=atoms,
                    cutoff_grid=cutoff_grid,
                    data_key=keys,
                    target_grid_spacing=target_grid_spacing,
                    boltzmann_constant=boltzmann_constant,
                    thermal_wavelength=thermal_wavelength,
                    geometry_cache=geometry_cache,
                    include_local_density_index=include_local_density_index,
                )
            )
            for atoms in configurations
        ]
        harmonize_optional_fields(data)
        if resolved_grid_info is not None:
            for frame in data:
                validate_frame_grid_info(frame, resolved_grid_info)
        return GridDataset(data)

    @classmethod
    def from_dict(
        cls,
        values: Dict[str, Any],
        cutoff_grid: int = 3,
        boltzmann_constant: float = DEFAULT_BOLTZMANN_CONSTANT,
        thermal_wavelength: Union[
            float, Sequence[float], np.ndarray
        ] = 1.0,
        grid_info: Optional[Mapping[str, Any]] = None,
        include_local_density_index: bool = True,
    ) -> "GridData":
        """Build one regular periodic grid from explicit metadata and fields.

        ``values`` requires ``grid_size``, ``grid_spacing``, ``n_types``, and
        either ``temperature`` or ``T``. Matching model metadata may instead
        be supplied through ``grid_info``. Density and external-potential
        fields can be assigned to the returned dictionary afterward. Optional
        ``rho`` and ``rho_std`` have shape ``[n_grid, n_types]``.
        ``dipole_density`` may be supplied with shape ``[n_grid, n_types, 3]``;
        its optional ``dipole_density_std`` has the same shape. Polarization
        tensor inputs retain their differentiation graph. Set
        ``include_local_density_index=False`` only for models whose local
        operators all use non-gather backends.
        """

        if not isinstance(values, dict):
            raise TypeError("values must be a dictionary")
        values = values.copy()
        if grid_info is not None:
            resolved = normalize_grid_info(grid_info)
            if "grid_spacing" in values:
                supplied_spacing = grid_spacing_array(
                    values["grid_spacing"]
                )
                if not np.allclose(
                    supplied_spacing,
                    resolved["grid_spacing"],
                ):
                    raise ValueError(
                        "values grid_spacing does not match grid_info"
                    )
            if "n_types" in values:
                supplied_n_types = _metadata_positive_integer(
                    values["n_types"],
                    "n_types",
                )
                if supplied_n_types != resolved["n_types"]:
                    raise ValueError(
                        "values n_types does not match grid_info"
                    )
            values["grid_spacing"] = resolved["grid_spacing"]
            values["n_types"] = resolved["n_types"]
            cutoff_grid = resolved["cutoff_grid"]
            boltzmann_constant = resolved["boltzmann_constant"]
            thermal_wavelength = resolved["thermal_wavelength"]

        cutoff_grid = nonnegative_integer(cutoff_grid, "cutoff_grid")
        boltzmann_constant = positive_scalar(
            boltzmann_constant,
            "boltzmann_constant",
        )
        include_local_density_index = boolean(
            include_local_density_index,
            "include_local_density_index",
        )

        allowed_keys = {
            "grid_size",
            "grid_spacing",
            "grid_center",
            "temperature",
            "T",
            "n_types",
            "excluded_mask",
            "mask",
            "rho",
            "rho_std",
            "dipole_density",
            "dipole_density_std",
        }
        unknown_keys = set(values) - allowed_keys
        if unknown_keys:
            raise KeyError(
                "unknown GridData.from_dict entries: {}".format(
                    sorted(unknown_keys)
                )
            )
        for required in ("grid_size", "grid_spacing", "n_types"):
            if required not in values:
                raise ValueError(
                    "values is missing required field '{}'".format(required)
                )
        temperature = values.get("temperature", values.get("T"))
        if temperature is None:
            raise ValueError(
                "values is missing required field 'temperature'"
            )

        grid_size = grid_size_array(values["grid_size"])
        grid_spacing = grid_spacing_array(values["grid_spacing"])
        temperature = _metadata_positive_scalar(temperature, "temperature")
        n_types = _metadata_positive_integer(values["n_types"], "n_types")
        grid_positions = np.indices(
            tuple(grid_size),
            dtype=np.int64,
        ).reshape(3, -1).T
        return cls(
            **build_grid_data(
                grid_positions=grid_positions,
                grid_size=grid_size,
                grid_spacing=grid_spacing,
                grid_center=values.get("grid_center"),
                temperature=temperature,
                n_types=n_types,
                cutoff_grid=cutoff_grid,
                boltzmann_constant=boltzmann_constant,
                thermal_wavelength=thermal_wavelength,
                excluded_mask=values.get("excluded_mask"),
                mask=values.get("mask"),
                rho=values.get("rho"),
                rho_std=values.get("rho_std"),
                dipole_density=values.get("dipole_density"),
                dipole_density_std=values.get("dipole_density_std"),
                include_local_density_index=include_local_density_index,
            )
        )
