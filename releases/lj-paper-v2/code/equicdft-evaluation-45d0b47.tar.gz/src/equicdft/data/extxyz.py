"""Private parsing, validation, and construction helpers for GridData."""

from typing import Any, Dict, List, Mapping, Optional

import numpy as np
import torch
from ase import Atoms

from .._validation import (
    boolean as _strict_boolean,
    nonnegative_integer as _strict_nonnegative_integer,
    positive_integer as _strict_positive_integer,
    positive_scalar as _strict_positive_scalar,
)
from ..geometry.stencil import (
    canonical_grid_order,
    coarsen_grid,
    get_neighbor_indices,
    grid_size_array,
    grid_spacing_array,
    make_stencil,
)
from ..geometry.grid import _grid_center_origin


GRID_INFO_KEYS = {
    "cutoff_grid",
    "grid_spacing",
    "n_types",
    "boltzmann_constant",
    "thermal_wavelength",
}


def normalize_grid_info(grid_info: Mapping[str, Any]) -> Dict[str, Any]:
    """Validate model grid metadata and return CPU-native values."""

    if not isinstance(grid_info, Mapping):
        raise TypeError("grid_info must be a mapping")
    missing_keys = GRID_INFO_KEYS - set(grid_info)
    if missing_keys:
        raise KeyError(
            "grid_info is missing required entries: {}".format(
                sorted(missing_keys)
            )
        )
    unknown_keys = set(grid_info) - GRID_INFO_KEYS
    if unknown_keys:
        raise KeyError(
            "unknown grid_info entries: {}".format(sorted(unknown_keys))
        )

    cutoff_grid = _metadata_nonnegative_integer(
        grid_info["cutoff_grid"],
        "grid_info cutoff_grid",
    )
    grid_spacing = grid_spacing_array(
        grid_info["grid_spacing"],
        "grid_info grid_spacing",
    )
    n_types = _metadata_positive_integer(
        grid_info["n_types"],
        "grid_info n_types",
    )
    boltzmann_constant = _metadata_positive_scalar(
        grid_info["boltzmann_constant"],
        "grid_info boltzmann_constant",
    )
    thermal_wavelength = _metadata_per_type_positive_values(
        grid_info["thermal_wavelength"],
        n_types,
        "grid_info thermal_wavelength",
    )
    return {
        "cutoff_grid": cutoff_grid,
        "grid_spacing": grid_spacing.tolist(),
        "n_types": n_types,
        "boltzmann_constant": boltzmann_constant,
        "thermal_wavelength": thermal_wavelength.tolist(),
    }


def validate_frame_grid_info(
    frame: Dict[str, torch.Tensor],
    grid_info: Mapping[str, Any],
) -> None:
    """Check that one processed EXTXYZ frame matches trained grid metadata."""

    if int(frame["n_types"].item()) != grid_info["n_types"]:
        raise ValueError("frame n_types does not match grid_info")
    frame_spacing = frame["grid_spacing"].detach().cpu().numpy()
    if not np.allclose(frame_spacing, grid_info["grid_spacing"]):
        raise ValueError("frame grid_spacing does not match grid_info")


def process_atoms(
    atoms: Atoms,
    cutoff_grid: int,
    data_key: Dict[str, str],
    target_grid_spacing: Optional[Any],
    boltzmann_constant: float,
    thermal_wavelength: Any,
    geometry_cache: Optional[Dict[Any, Any]],
    include_local_density_index: bool = True,
) -> Dict[str, torch.Tensor]:
    """Extract and canonicalize one EXTXYZ frame, then build its tensors."""

    positions = np.asarray(
        _required_source_value(
            atoms,
            data_key["grid_positions"],
            "grid_positions",
        ),
        dtype=float,
    )
    indexing_value = _get_source_value(atoms, data_key["grid_indexing"])
    indexing = str(
        "zero_based" if indexing_value is None else indexing_value
    ).lower()
    if indexing in ("one_based", "one-based", "1_based"):
        positions = positions - 1.0

    grid_size_value = _get_source_value(atoms, data_key["grid_size"])
    ordering = canonical_grid_order(positions, grid_size_value)
    grid_size = ordering.grid_size
    n_grid = int(np.prod(grid_size))
    order = ordering.order
    grid_positions = ordering.positions[order]

    grid_center = _get_source_value(atoms, data_key["grid_center"])
    if grid_center is not None:
        grid_center = np.asarray(grid_center)
        if grid_center.shape != (n_grid, 3):
            raise ValueError("grid_center must have shape [n_grid, 3]")
        grid_center = grid_center[order]

    rho = _ordered_optional_field(atoms, data_key["rho"], order, "rho")
    rho_std = _ordered_optional_field(
        atoms, data_key["rho_std"], order, "rho_std"
    )
    excluded_mask = _ordered_optional_mask(
        atoms,
        data_key["excluded_mask"],
        order,
    )
    mask = _ordered_optional_mask(atoms, data_key["mask"], order, name="mask")
    V_ext = _ordered_optional_field(
        atoms,
        data_key["V_ext"],
        order,
        "V_ext",
    )
    if rho is None and V_ext is None:
        raise ValueError("frame must contain at least one of rho or V_ext")
    n_types = rho.shape[1] if rho is not None else V_ext.shape[1]
    if rho is not None and V_ext is not None:
        if rho.shape[1] != V_ext.shape[1]:
            raise ValueError(
                "rho and V_ext must contain the same number of columns"
            )

    dipole_density = _ordered_optional_field(
        atoms, data_key["dipole_density"], order, "dipole_density"
    )
    dipole_density_std = _ordered_optional_field(
        atoms, data_key["dipole_density_std"], order, "dipole_density_std"
    )
    for name, field in (
        ("dipole_density", dipole_density),
        ("dipole_density_std", dipole_density_std),
    ):
        if field is not None and field.shape != (n_grid, 3 * n_types):
            raise ValueError(
                "EXTXYZ {} must have shape [n_grid, 3*n_types]".format(name)
            )
    if dipole_density is not None:
        dipole_density = dipole_density.reshape(n_grid, n_types, 3)
    if dipole_density_std is not None:
        dipole_density_std = dipole_density_std.reshape(n_grid, n_types, 3)

    grid_spacing = grid_spacing_array(
        _required_source_value(
            atoms,
            data_key["grid_spacing"],
            "grid_spacing",
        )
    )
    if grid_center is not None:
        _grid_center_origin(grid_center, grid_positions, grid_spacing)
    if target_grid_spacing is not None:
        if not np.allclose(
            grid_spacing_array(target_grid_spacing),
            grid_spacing,
            rtol=1.0e-10,
            atol=1.0e-10,
        ):
            for name, field in (
                ("rho_std", rho_std),
                ("dipole_density_std", dipole_density_std),
            ):
                if field is not None:
                    raise ValueError(
                        "{} cannot be coarsened without covariance information; "
                        "supply fields and uncertainties on the final grid".format(name)
                    )
        fields_to_coarsen = [
            field for field in (rho, V_ext) if field is not None
        ]
        if dipole_density is not None:
            # Validate before averaging: opposite invalid dipoles in an
            # excluded block must not cancel into a valid coarse field.
            _normalize_dipole_density(
                dipole_density,
                n_grid,
                n_types,
                _normalize_excluded_mask(excluded_mask, n_grid),
            )
            fields_to_coarsen.append(dipole_density.reshape(n_grid, -1))
        for optional_mask in (excluded_mask, mask):
            if optional_mask is not None:
                fields_to_coarsen.append(optional_mask[:, None].astype(float))
        if grid_center is not None:
            fields_to_coarsen.append(grid_center)
        fields, grid_positions, grid_spacing = coarsen_grid(
            values=np.column_stack(fields_to_coarsen),
            grid_positions=grid_positions,
            grid_spacing=grid_spacing,
            target_grid_spacing=target_grid_spacing,
        )
        field_start = 0
        if rho is not None:
            rho = fields[:, field_start : field_start + n_types]
            field_start += n_types
        if V_ext is not None:
            V_ext = fields[:, field_start : field_start + n_types]
            field_start += n_types
        if dipole_density is not None:
            dipole_density = fields[
                :, field_start : field_start + 3 * n_types
            ].reshape(-1, n_types, 3)
            field_start += 3 * n_types
        coarse_masks = []
        for name, optional_mask in (("excluded_mask", excluded_mask), ("mask", mask)):
            if optional_mask is not None:
                fraction = fields[:, field_start]
                if not np.all(np.isclose(fraction, 0.) | np.isclose(fraction, 1.)):
                    adjective = "accessible" if name == "excluded_mask" else "frozen"
                    raise ValueError("coarsening would create partially {} grid points; "
                                     "supply {} on the target grid".format(adjective, name))
                optional_mask = np.isclose(fraction, 1.)
                field_start += 1
            coarse_masks.append(optional_mask)
        excluded_mask, mask = coarse_masks
        if grid_center is not None:
            grid_center = fields[:, field_start : field_start + 3]
        grid_size = grid_positions.max(axis=0) + 1
        if excluded_mask is None:
            excluded_mask = np.zeros(len(grid_positions), dtype=bool)

    temperature = _metadata_positive_scalar(
        _required_source_value(
            atoms,
            data_key["temperature"],
            "temperature",
        ),
        "temperature",
    )
    return build_grid_data(
        grid_positions=grid_positions,
        grid_size=grid_size,
        grid_spacing=grid_spacing,
        grid_center=grid_center,
        temperature=temperature,
        n_types=n_types,
        cutoff_grid=cutoff_grid,
        boltzmann_constant=boltzmann_constant,
        thermal_wavelength=thermal_wavelength,
        rho=rho,
        rho_std=rho_std,
        V_ext=V_ext,
        dipole_density=dipole_density,
        dipole_density_std=dipole_density_std,
        mu=_get_source_value(atoms, data_key["mu"]),
        excluded_mask=excluded_mask,
        mask=mask,
        geometry_cache=geometry_cache,
        include_thermal_wavelength=V_ext is not None,
        include_local_density_index=include_local_density_index,
    )


def build_grid_data(
    grid_positions: Any,
    grid_size: Any,
    grid_spacing: Any,
    temperature: Any,
    n_types: Any,
    cutoff_grid: Any,
    boltzmann_constant: Any,
    thermal_wavelength: Any,
    rho: Optional[Any] = None,
    V_ext: Optional[Any] = None,
    mu: Optional[Any] = None,
    excluded_mask: Optional[Any] = None,
    geometry_cache: Optional[Dict[Any, Any]] = None,
    include_thermal_wavelength: bool = True,
    include_local_density_index: bool = True,
    grid_center: Optional[Any] = None,
    dipole_density: Optional[Any] = None,
    rho_std: Optional[Any] = None,
    dipole_density_std: Optional[Any] = None,
    mask: Optional[Any] = None,
) -> Dict[str, torch.Tensor]:
    """Build the canonical tensor dictionary from normalized grid fields."""

    grid_size_values = grid_size_array(grid_size)
    grid_spacing_values = grid_spacing_array(grid_spacing)
    temperature_value = _metadata_positive_scalar(temperature, "temperature")
    n_type_values = _metadata_positive_integer(n_types, "n_types")
    cutoff_value = _metadata_nonnegative_integer(cutoff_grid, "cutoff_grid")
    boltzmann_value = _metadata_positive_scalar(
        boltzmann_constant,
        "boltzmann_constant",
    )
    include_local_density_index = _strict_boolean(
        include_local_density_index,
        "include_local_density_index",
    )

    positions = np.asarray(grid_positions, dtype=np.int64)
    n_grid = int(np.prod(grid_size_values))
    if positions.shape != (n_grid, 3):
        raise ValueError(
            "grid_positions must have shape [prod(grid_size), 3]"
        )
    rho_values = _normalize_grid_field(
        rho,
        n_grid,
        n_type_values,
        "rho",
        nonnegative=True,
    )
    V_ext_values = _normalize_grid_field(
        V_ext,
        n_grid,
        n_type_values,
        "V_ext",
    )
    rho_std_values = _normalize_grid_field(
        rho_std, n_grid, n_type_values, "rho_std", nonnegative=True
    )
    if rho_std_values is not None and rho_values is None:
        raise ValueError("rho_std requires rho")
    mu_values = _normalize_optional_mu(mu, n_type_values)
    excluded_mask_values = _normalize_excluded_mask(excluded_mask, n_grid)
    if np.all(excluded_mask_values):
        raise ValueError("masks must leave at least one accessible grid point")
    dipole_density_values = _normalize_dipole_density(
        dipole_density,
        n_grid,
        n_type_values,
        excluded_mask_values,
    )
    dipole_density_std_values = _normalize_dipole_density(
        dipole_density_std,
        n_grid,
        n_type_values,
        excluded_mask_values,
        name="dipole_density_std",
        nonnegative=True,
    )
    if dipole_density_std_values is not None and dipole_density_values is None:
        raise ValueError("dipole_density_std requires dipole_density")
    if rho_std_values is not None and np.any(
        rho_std_values[excluded_mask_values] != 0.0
    ):
        raise ValueError("rho_std must be zero at excluded grid points")
    if rho_values is not None and np.any(
        np.abs(rho_values[excluded_mask_values]) > 1.0e-12
    ):
        raise ValueError("rho must be zero at excluded grid points")
    if rho_values is not None:
        rho_values = rho_values.copy()
        rho_values[excluded_mask_values] = 0.0
    wavelength_values = None
    if include_thermal_wavelength:
        wavelength_values = _metadata_per_type_positive_values(
            thermal_wavelength,
            n_type_values,
            "thermal_wavelength",
        )

    local_density_index, local_density_positions = _geometry_tensors(
        grid_positions=positions,
        grid_size=grid_size_values,
        cutoff_grid=cutoff_value,
        geometry_cache=geometry_cache,
        include_local_density_index=include_local_density_index,
    )
    beta = 1.0 / (boltzmann_value * temperature_value)
    dtype = torch.get_default_dtype()
    data = {
        "temperature": torch.tensor(temperature_value, dtype=dtype),
        "beta": torch.tensor(beta, dtype=dtype),
        "n_types": torch.tensor(n_type_values, dtype=torch.long),
        "grid_size": torch.tensor(grid_size_values, dtype=torch.long),
        "grid_spacing": torch.tensor(grid_spacing_values, dtype=dtype),
        "index": torch.arange(n_grid, dtype=torch.long),
        "grid_positions": torch.tensor(positions, dtype=torch.long),
        "excluded_mask": torch.tensor(
            excluded_mask_values,
            dtype=torch.bool,
        ),
        "local_density_positions": local_density_positions,
    }
    if mask is not None:
        data["mask"] = torch.tensor(_normalize_voxel_mask(mask, n_grid, "mask"), dtype=torch.bool)
    if grid_center is not None:
        centers = torch.as_tensor(grid_center)
        if centers.shape != (n_grid, 3):
            raise ValueError("grid_center must have shape [n_grid, 3]")
        _grid_center_origin(grid_center, positions, grid_spacing_values)
        data["grid_center"] = torch.as_tensor(grid_center, dtype=torch.float64)
    if local_density_index is not None:
        data["local_density_index"] = local_density_index
    if rho_values is not None:
        data["rho"] = torch.tensor(rho_values, dtype=dtype)
    if rho_std_values is not None:
        data["rho_std"] = torch.tensor(rho_std_values, dtype=dtype)
    if V_ext_values is not None:
        data["V_ext"] = torch.tensor(V_ext_values, dtype=dtype)
    if dipole_density_values is not None:
        # Unlike torch.tensor(...), .to(...) retains a supplied live graph.
        data["dipole_density"] = dipole_density_values.to(dtype=dtype)
    if dipole_density_std_values is not None:
        data["dipole_density_std"] = dipole_density_std_values.to(dtype=dtype)
    if wavelength_values is not None:
        data["thermal_wavelength"] = torch.tensor(
            wavelength_values,
            dtype=dtype,
        )
    if mu_values is not None:
        data["mu"] = torch.tensor(mu_values, dtype=dtype)
        data["beta_mu"] = torch.tensor(beta * mu_values, dtype=dtype)
    return data


def harmonize_optional_fields(data: List[Dict[str, torch.Tensor]]) -> None:
    """Make optional field metadata compatible with default PyTorch collation."""

    if any("grid_center" in frame for frame in data):
        for frame in data:
            if "grid_center" not in frame:
                frame["grid_center"] = frame["grid_positions"].double() * frame["grid_spacing"].double()

    for name in ("rho_std", "dipole_density_std"):
        available = [name in frame for frame in data]
        if any(available) and not all(available):
            raise ValueError("{} must be present in every frame or none".format(name))

    has_beta_mu = ["beta_mu" in frame for frame in data]
    if not any(has_beta_mu) or all(has_beta_mu):
        return
    for frame, available in zip(data, has_beta_mu):
        if available:
            continue
        n_types = int(frame["n_types"].item())
        missing_mu = torch.full(
            (n_types,),
            float("nan"),
            dtype=frame["temperature"].dtype,
        )
        frame["mu"] = missing_mu.clone()
        frame["beta_mu"] = missing_mu


def _metadata_scalar(value: Any, name: str) -> float:
    """Unwrap one scalar value read from ASE or NumPy metadata."""

    try:
        values = np.asarray(value, dtype=float).reshape(-1)
    except (TypeError, ValueError):
        raise ValueError("{} must be a scalar".format(name))
    if values.size != 1:
        raise ValueError("{} must be a scalar".format(name))
    return float(values[0])


def _metadata_positive_integer(value: Any, name: str) -> int:
    """Coerce serialized scalar metadata to a positive integer."""

    integer = _metadata_nonnegative_integer(value, name)
    return _strict_positive_integer(integer, name)


def _metadata_nonnegative_integer(value: Any, name: str) -> int:
    """Coerce serialized scalar metadata to a nonnegative integer."""

    scalar = _metadata_scalar(value, name)
    if not np.isfinite(scalar):
        raise ValueError("{} must be a nonnegative integer".format(name))
    integer = int(np.rint(scalar))
    if not np.isclose(scalar, integer):
        raise ValueError("{} must be a nonnegative integer".format(name))
    return _strict_nonnegative_integer(integer, name)


def _metadata_positive_scalar(value: Any, name: str) -> float:
    """Coerce serialized scalar metadata to a finite positive value."""

    scalar = _metadata_scalar(value, name)
    return _strict_positive_scalar(scalar, name)


def _metadata_per_type_positive_values(
    value: Any,
    n_types: int,
    name: str,
) -> np.ndarray:
    """Coerce metadata to one finite positive value per component."""

    try:
        values = np.asarray(value, dtype=float).reshape(-1)
    except (TypeError, ValueError):
        raise ValueError(
            "{} must contain one positive value per type".format(name)
        )
    if values.size == 1:
        values = np.repeat(values, n_types)
    if (
        values.size != n_types
        or not np.all(np.isfinite(values))
        or np.any(values <= 0.0)
    ):
        raise ValueError(
            "{} must contain one positive value per type".format(name)
        )
    return values


def _get_source_value(atoms: Atoms, source_key: str) -> Optional[Any]:
    if source_key == "positions":
        return atoms.get_positions()
    if source_key in atoms.info:
        return atoms.info[source_key]
    if source_key in atoms.arrays:
        return atoms.arrays[source_key]
    # ASE moves reserved EXTXYZ properties (e.g. polarization) into a stored
    # calculator result even when they were serialized as per-grid columns.
    if atoms.calc is not None and source_key in atoms.calc.results:
        return atoms.calc.results[source_key]
    return None


def _required_source_value(atoms: Atoms, source_key: str, field: str) -> Any:
    value = _get_source_value(atoms, source_key)
    if value is None:
        raise ValueError(
            "frame is missing '{}' for GridData field '{}'".format(
                source_key,
                field,
            )
        )
    return value


def _ordered_optional_field(
    atoms: Atoms,
    source_key: str,
    order: np.ndarray,
    name: str,
) -> Optional[np.ndarray]:
    value = _get_source_value(atoms, source_key)
    if value is None:
        return None
    field = np.asarray(value, dtype=float)[order]
    if field.ndim == 1:
        field = field[:, None]
    if field.ndim != 2:
        raise ValueError(
            "{} must have shape [n_grid] or [n_grid, n_types]".format(name)
        )
    return field


def _ordered_optional_mask(
    atoms: Atoms,
    source_key: str,
    order: np.ndarray,
    name: str = "excluded_mask",
) -> Optional[np.ndarray]:
    """Return an optional voxel mask in canonical grid order."""

    value = _get_source_value(atoms, source_key)
    if value is None:
        return None
    if name == "excluded_mask":
        return _normalize_excluded_mask(np.asarray(value)[order], len(order))
    return _normalize_voxel_mask(np.asarray(value)[order], len(order), name)


def _normalize_grid_field(
    value: Optional[Any],
    n_grid: int,
    n_types: int,
    name: str,
    nonnegative: bool = False,
) -> Optional[np.ndarray]:
    if value is None:
        return None
    field = np.asarray(value, dtype=float)
    if field.ndim == 1:
        field = field[:, None]
    if field.shape != (n_grid, n_types):
        raise ValueError(
            "{} must have shape [n_grid, n_types]".format(name)
        )
    if not np.all(np.isfinite(field)):
        raise ValueError("{} must contain only finite values".format(name))
    if nonnegative and np.any(field < 0.0):
        raise ValueError("{} must contain only nonnegative values".format(name))
    return field


def _normalize_excluded_mask(
    value: Optional[Any],
    n_grid: int,
) -> np.ndarray:
    """Return a Boolean exclusion mask with one value per grid point."""

    mask = _normalize_voxel_mask(value, n_grid, "excluded_mask")
    if np.all(mask):
        raise ValueError("excluded_mask must leave at least one accessible grid point")
    return mask


def _normalize_voxel_mask(value: Optional[Any], n_grid: int, name: str) -> np.ndarray:
    """Shared Boolean/binary input normalization for per-voxel masks."""

    if value is None:
        return np.zeros(n_grid, dtype=bool)
    mask = np.asarray(value)
    if mask.ndim == 2 and mask.shape[1] == 1:
        mask = mask[:, 0]
    if mask.shape != (n_grid,):
        raise ValueError("{} must have shape [n_grid]".format(name))
    if mask.dtype != np.bool_:
        try:
            numeric_mask = np.asarray(mask, dtype=float)
        except (TypeError, ValueError):
            raise ValueError(
                "{} values must be Boolean or binary".format(name)
            )
        if (
            not np.all(np.isfinite(numeric_mask))
            or not np.all((numeric_mask == 0.0) | (numeric_mask == 1.0))
        ):
            raise ValueError(
                "{} values must be Boolean or binary".format(name)
            )
        mask = numeric_mask.astype(bool)
    else:
        mask = mask.astype(bool, copy=False)
    return mask


def _normalize_dipole_density(
    value: Optional[Any],
    n_grid: int,
    n_types: int,
    excluded_mask: np.ndarray,
    name: str = "dipole_density",
    nonnegative: bool = False,
) -> Optional[torch.Tensor]:
    """Validate a signed polar-vector field without detaching tensor inputs."""

    if value is None:
        return None
    field = torch.as_tensor(value)
    if field.shape != (n_grid, n_types, 3):
        raise ValueError(
            "{} must have shape [n_grid, n_types, 3]".format(name)
        )
    if field.is_complex() or not torch.all(torch.isfinite(field)).item():
        raise ValueError("{} must contain only finite real values".format(name))
    if nonnegative and torch.any(field < 0.0).item():
        raise ValueError("{} must contain only nonnegative values".format(name))
    mask = torch.as_tensor(excluded_mask, device=field.device)
    if torch.any(field[mask] != 0.0).item():
        raise ValueError("{} must be zero at excluded grid points".format(name))
    return field


def _normalize_optional_mu(
    value: Optional[Any],
    n_types: int,
) -> Optional[np.ndarray]:
    if value is None:
        return None
    mu = np.asarray(value, dtype=float).reshape(-1)
    if mu.size == 1:
        mu = np.repeat(mu, n_types)
    if mu.size != n_types:
        raise ValueError("mu must contain one value or one value per type")
    if np.all(np.isnan(mu)):
        return None
    if not np.all(np.isfinite(mu)):
        raise ValueError("mu values must be finite")
    return mu


def _geometry_tensors(
    grid_positions: np.ndarray,
    grid_size: np.ndarray,
    cutoff_grid: int,
    geometry_cache: Optional[Dict[Any, Any]],
    include_local_density_index: bool,
) -> Any:
    geometry_key = (
        include_local_density_index,
        cutoff_grid,
    ) + tuple(int(value) for value in grid_size)
    cached = (
        None if geometry_cache is None else geometry_cache.get(geometry_key)
    )
    if cached is not None:
        return cached
    if include_local_density_index:
        local_density_index, local_density_positions = get_neighbor_indices(
            grid_positions=grid_positions,
            cutoff_grid=cutoff_grid,
        )
        index_tensor = torch.tensor(local_density_index, dtype=torch.long)
    else:
        local_density_positions = make_stencil(cutoff_grid)
        index_tensor = None
    geometry = (
        index_tensor,
        torch.tensor(local_density_positions, dtype=torch.long),
    )
    if geometry_cache is not None:
        geometry_cache[geometry_key] = geometry
    return geometry
